# Hoofdstuk 11 – Hout

## Opbouw en houtsoorten

**Naaldhout** komt van naaldbomen en **loofhout** van loofbomen. De namen zeggen waar het hout vandaan komt. Hardheid en weerstand tegen aantasting verschillen per soort. **Vuren** wordt veel gebruikt voor balken en binnentimmerwerk. **Beuken** is hard en bruikbaar voor meubels en parket, maar heeft van nature weinig weerstand tegen houtrot buiten.

De **cambiumlaag** maakt nieuwe hout- en bastcellen, waardoor de stam dikker wordt. Het buitenste **spinthout** voert water en mineralen naar boven. Het oudere **kernhout** ligt verder naar binnen en doet niet meer mee aan dit transport. Het **merg** ligt in het midden. Door verschillen in groeisnelheid ontstaan **groeiringen**. Op het **kopse vlak**, dwars op de lengte van de stam, zie je de ringen als cirkels. Een **radiaal vlak** loopt in de lengte door het hart. Een **tangentiaal vlak** loopt in de lengte langs het hart en kan een vlammenpatroon tonen.

## Zagen, drogen en sterkte

Hout **werkt** wanneer het vocht opneemt of afgeeft. Het zwelt bij vochtopname en krimpt bij droging. Langs de vezels verandert de maat weinig. In de richting van de groeiringen, tangentiaal, krimpt hout meer dan dwars op de ringen, radiaal. Daardoor kan een **dosse gezaagde** plank, herkenbaar aan de vaak vlamvormige tekening, in de breedte krimpen en hol trekken. Bij **kwartiers gezaagd** hout staan de ringen bijna haaks op het brede vlak. Het verandert doorgaans minder in de breedte en trekt minder snel hol. Stem het **houtvochtgehalte** bij verwerking af op de gebruiksomgeving.

Een **wankant** is een restant van de ronde stamkant. **Meskant gezaagd** hout heeft geen wankant. Een **kwast** of **noest** zit waar een tak groeide en kan de sterkte verminderen doordat de vezels eromheen afbuigen. Kies voor een dragend onderdeel hout met een **sterkteklasse** die past bij het constructief ontwerp. Die klasse gaat over mechanische eigenschappen. De **natuurlijke duurzaamheidsklasse** geeft aan hoe goed onbehandeld hout, doorgaans het kernhout, bestand is tegen biologische aantasting zoals houtrot.

## Plaatmateriaal en dragende elementen

**Fineer** is een dun vel hout. **Multiplex** bestaat uit verlijmde fineerlagen waarvan de vezelrichting telkens kruist. Dat beperkt het werken en maakt de plaat in beide richtingen stijver dan bij lagen met één vezelrichting. **Meubelplaat** heeft een kern van latten met fineer aan de buitenzijden. **Spaanplaat** bevat geperste houtspaanders en kan bij vocht opzwellen. **OSB** bestaat uit grove, gericht gelegde houtspaanders en wordt onder meer gebruikt voor vloeren en dakbeschot. **MDF** bestaat uit fijne geperste houtvezels. Het is glad en gelijkmatig te bewerken. Kies bij vochtbelasting een plaatkwaliteit die bij die toepassing past.

In **gelamineerd hout** lopen de vezels van de verlijmde houtlagen in dezelfde richting. Zo maak je bijvoorbeeld lange of gebogen liggers. Bij **kruislaaghout (CLT)** liggen dikke houtlagen kruislings verlijmd. Dat levert stijve, dragende platen op voor wanden, vloeren en daken. Anders dan multiplex bestaat CLT uit houten lamellen en niet uit dun fineer.

## Aantasting en bescherming

**Houtrot** ontstaat door schimmels die de houtcellen aantasten. Langdurig vocht vergroot het risico. **Blauwschimmel** verkleurt vooral het spinthout en breekt de dragende celwanden doorgaans niet af. Ook insectenlarven kunnen schade aanrichten. De **huisboktor** tast vooral spinthout van naaldhout aan en laat vaak ovale uitvliegopeningen achter. Zo’n opening alleen bewijst niet dat de aantasting nog actief is.

Beperk vocht door water af te voeren en het hout te laten drogen. **Impregneren** brengt een beschermend middel in het hout. **Thermische modificatie** verandert de eigenschappen door warmte, **acetylering** doet dat chemisch. Bij beide kan hout minder vocht opnemen en minder werken. **FSC** en **PEFC** geven informatie over gecertificeerde herkomst en ketenborging. Voor sterkte en toepassingsgeschiktheid zijn aparte gegevens nodig.
