# Hoofdstuk 16 – Hang- en sluitwerk en bouwbeslag

## Ophangen en bewegen

**Hangwerk** draagt en geleidt beweegbare delen, zoals deuren en ramen. **Sluitwerk** houdt die delen gesloten of zet ze in geopende stand vast. **Bouwbeslag** omvat onderdelen waarmee je bouwdelen bedient, afwerkt, ophangt of bevestigt. Voorbeelden zijn deurkrukken, schilden, briefplaten en leuningdragers. Kies het beslag op basis van het gewicht, de afmetingen, de draairichting, het gebruik en de ondergrond.

Een **scharnier** heeft meestal twee bladen die om een pen draaien. De bladen zitten aan het beweegbare deel en aan het kozijn. Een **lagerscharnier** heeft een lager dat de wrijving bij het draaien beperkt. Dat is vooral nuttig bij zware of vaak gebruikte deuren. Een **paumelle** bestaat uit twee delen die over elkaar worden gehangen. De pen zit vast aan één deel. Bij een **inboorpaumelle** worden de bevestigingsdelen in voorgeboorde gaten aangebracht. Een **oplooppaumelle** tilt het deurblad iets op tijdens het openen, waardoor het door zijn eigen gewicht terug wil draaien.

Een **geheng** is een lang scharnierbeslag voor bijvoorbeeld een poort, hek of opgeklampte deur. De lange staart verdeelt de bevestiging over een groter deel van het deurblad. Een **duimheng** draait om een vaste pen, de **duim**. Een **speun** ondersteunt een draaipunt. Een tuimelraam kan draaien op speunen aan de zijkanten. Bij een **taatsdeur** zit de verticale draaias tussen draaipunten boven en onder. Een **deurdranger** of **vloerveer** laat de deur na gebruik automatisch sluiten. Een **raamuitzetter** houdt een raam in een gekozen open stand.

## Sluiten en vergrendelen

Een **klink** grijpt in een sluitstuk en kan een deur dicht houden. Een **dagschoot** is meestal verend en valt bij het sluiten in de **sluitplaat** of **sluitkast** in het kozijn. Met de kruk trek je de dagschoot terug. Een **nachtschoot** wordt apart bediend, bijvoorbeeld met een sleutel of draaiknop, en vergrendelt de deur. Een **loopslot** heeft alleen een dagschoot. Een **dag- en nachtslot** heeft beide schoten. Een **oplegslot** zit op het deurblad. Bij een **insteekslot** zit de slotkast in de rand van de deur. Een **cilinder** is het onderdeel dat de juiste sleutel laat draaien om het slot te bedienen. Bij veel sloten is de cilinder apart te vervangen.

Een **schuif** of **grendel** blokkeert de beweging met een verschuivend deel dat in een sluitstuk valt. Een **espagnolet** bedient met één handeling sluitingen boven en onder, bijvoorbeeld bij hoge deuren of dubbele ramen. Een **meerpuntssluiting** vergrendelt op meerdere plaatsen langs de sluitzijde, zodat de deur op meer dan één punt aan het kozijn vastzit. Bij een **schuifdeurslot** kan een haakvormige schoot achter het sluitstuk grijpen en voorkomen dat het blad wegschuift.

## Veiligheid en bediening

Bij **inbraakwering** werkt het beslag samen met het deurblad, het kozijn, de sluitstukken en de bevestiging. Een **dievenklauw** houdt een gesloten deur aan de scharnierzijde in het kozijn als de scharnieren worden geforceerd. Een **SKG-keurmerk** geeft aan dat beslag op inbraakwerendheid is beproefd. De prestatie van de hele deur hangt ook af van de combinatie en montage. Bij **centraalsluiting** openen verschillende individuele sleutels ook een gezamenlijke deur. Bij een **hoofdsleutelsysteem** opent een hoofdsleutel meerdere sloten, terwijl gebruikerssleutels alleen de aan hen toegewezen sloten bedienen.

Een **panieksluiting** maakt het mogelijk een daarvoor bedoelde vluchtdeur van binnenuit snel te openen zonder sleutel, bijvoorbeeld met een horizontale drukstang. Een vluchtdeur moet bruikbaar blijven zoals het vluchtplan en de toepasselijke eisen voorschrijven. Een **leuningdrager** verbindt de trapleuning met de wand. Kies een bevestiging die bij de wand en de belasting past.
