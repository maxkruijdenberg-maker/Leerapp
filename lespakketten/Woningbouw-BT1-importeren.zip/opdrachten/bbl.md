# Opdrachten — 11 • Wat regelt het Bbl?

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Waar staat Bbl voor?
A. Bureau bouwkundige leningen
B. Besluit bouwwerken leefomgeving
C. Bestemmingsbesluit landelijke woningprijzen

## Vraag 2
Onder welke groep vallen ventilatie en daglicht in de beschreven indeling?
A. Alleen welstand
B. Gezondheid
C. Alleen leges

## Vraag 3
Waarom kun je niet voor elk gebouw zonder meer dezelfde eis gebruiken?
A. Omdat regels vrijwillig zijn
B. Omdat alleen de kleur telt
C. Omdat gebruiksfunctie en bestaande bouw of nieuwbouw verschil maken

## Vraag 4
Noem een voorbeeld van veiligheid, gezondheid en energie/milieu.

# Antwoorden en uitleg

## Vraag 1
B. Besluit bouwwerken leefomgeving
Bbl is de afkorting van Besluit bouwwerken leefomgeving.

## Vraag 2
B. Gezondheid
Ventilatie en daglicht dragen bij aan een gezonde binnenruimte.

## Vraag 3
C. Omdat gebruiksfunctie en bestaande bouw of nieuwbouw verschil maken
De functie en het soort bouwsituatie bepalen welke eisen van toepassing zijn.

## Vraag 4
Veiligheid: een sterke constructie, brandveiligheid of kunnen vluchten. Gezondheid: ventilatie, daglicht of vochtwering. Energie/milieu: beperken van warmteverlies, luchtlekken of milieubelasting van materialen. Eén voorbeeld per groep is voldoende.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
