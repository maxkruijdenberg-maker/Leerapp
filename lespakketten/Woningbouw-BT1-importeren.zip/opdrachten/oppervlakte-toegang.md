# Opdrachten — 13 • Oppervlakte, techniek en toegankelijkheid

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Welke norm noemt het boek voor gebruiksoppervlak?
A. NEN 2580
B. De legesverordening
C. Een welstandsnota

## Vraag 2
Waarom is een woonkamer met een brandmelder niet vanzelf een technische ruimte?
A. Omdat brandmelders verboden zijn
B. Omdat de bestemming van de ruimte telt
C. Omdat alle kamers technisch zijn

## Vraag 3
Wat is een toegankelijkheidssector?
A. Alleen de oprit voor auto’s
B. Een afgesloten technische berging
C. Een gedeelte dat een rolstoelgebruiker zelfstandig kan bereiken en gebruiken

## Vraag 4
Je bereikt via een gang een slaapkamer en een technische ruimte. Welke taak heeft de gang?

# Antwoorden en uitleg

## Vraag 1
A. NEN 2580
NEN 2580 is de genoemde norm voor oppervlaktebepaling.

## Vraag 2
B. Omdat de bestemming van de ruimte telt
Een technische ruimte is bedoeld voor essentiële gebouwapparatuur. Eén installatie in een woonkamer verandert de functie niet automatisch.

## Vraag 3
C. Een gedeelte dat een rolstoelgebruiker zelfstandig kan bereiken en gebruiken
Het gaat om zelfstandig toegang hebben en de ruimte kunnen gebruiken.

## Vraag 4
De gang dient om andere ruimten te bereiken. Dat is de taak van een verkeersruimte. De gang is daardoor niet hetzelfde als de slaapkamer of de technische ruimte.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
