# Opdrachten — 02 • Vrijstaand, rijwoning en woongebouw

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Wanneer spreekt de hier gebruikte Bbl-omschrijving van een woongebouw?
A. Alleen als er minimaal twaalf verdiepingen zijn
B. Bij twee of meer woningen bereikbaar via een gemeenschappelijke verkeersroute
C. Bij iedere vrijstaande woning

## Vraag 2
Vanaf hoeveel aaneengebouwde woningen noemt het boek het een rij?
A. Vier
B. Drie
C. Twee

## Vraag 3
Wat is kenmerkend voor een bungalow volgens de tekst?
A. Meestal één bouwlaag en een plat dak
B. Altijd een gemeenschappelijke galerij
C. Altijd drie woonlagen

## Vraag 4
Waarom kun je vier gestapelde woningen niet met alleen de tabel in dit boek altijd eenduidig middelhoog of hoog noemen?

# Antwoorden en uitleg

## Vraag 1
B. Bij twee of meer woningen bereikbaar via een gemeenschappelijke verkeersroute
Het gaat om meerdere woningen én een gemeenschappelijke verkeersroute.

## Vraag 2
B. Drie
Het boek beschrijft een rijwoning als onderdeel van minimaal drie gekoppelde woningen.

## Vraag 3
A. Meestal één bouwlaag en een plat dak
Dit is de gebruikelijke omschrijving in het boek; het woord meestal is belangrijk.

## Vraag 4
Omdat de omschrijvingen overlappen: middelhoog noemt drie of vier en hoogbouw vier of meer. Vier staat dus bij beide.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
