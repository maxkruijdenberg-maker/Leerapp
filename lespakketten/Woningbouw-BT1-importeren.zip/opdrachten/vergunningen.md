# Opdrachten — 09 • Vergunning, melding, welstand en monumenten

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Een bouwwerk is vergunningvrij. Wat betekent dat?
A. Ook de buren hebben geen rechten meer
B. Er gelden nooit technische regels
C. Voor die activiteit is geen vergunning nodig; andere regels kunnen wel gelden

## Vraag 2
Waarover gaat welstand?
A. Uiterlijk en plaatsing in relatie tot de omgeving
B. Alleen de dikte van isolatie
C. Alleen de hoogte van de hypotheek

## Vraag 3
Je wilt een dakkapel maken. Welke aanpak past bij de bron?
A. Aannemen dat iedere dakkapel vergunningvrij is
B. Alleen vragen of de aannemer het mooi vindt
C. Voorwaarden, locatie, Omgevingsloket en omgevingsplan controleren

## Vraag 4
Leg het verschil uit tussen een vergunning en een melding.

# Antwoorden en uitleg

## Vraag 1
C. Voor die activiteit is geen vergunning nodig; andere regels kunnen wel gelden
Vergunningvrij is niet regelvrij. Denk aan Bbl, omgevingsplan en privaatrechtelijke regels.

## Vraag 2
A. Uiterlijk en plaatsing in relatie tot de omgeving
Welstand beoordeelt de verschijningsvorm en de relatie tot de omgeving.

## Vraag 3
C. Voorwaarden, locatie, Omgevingsloket en omgevingsplan controleren
De voorwaarden hangen onder andere af van maatvoering, plaatsing en eventuele monumentale bescherming.

## Vraag 4
Bij een vergunning moet de overheid toestemming verlenen voor de activiteit. Bij een melding informeer je de overheid volgens de meldingsregels; dat is geen volledige vergunningprocedure. In beide gevallen blijven toepasselijke eisen gelden.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
