# Opdrachten — 03 • Herken de indeling van een woning

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Welk woningtype zie je op deze plattegrond?
Afbeelding: afbeeldingen/suite.jpg (ook zichtbaar bij de interactieve vraag).
A. Duplexwoning
B. Drive-inwoning
C. Suitetype

## Vraag 2
Welke indeling zie je hier?
Afbeelding: afbeeldingen/doorzon.jpg (ook zichtbaar bij de interactieve vraag).
A. Doorzontype
B. Maisonette
C. Portiekflat

## Vraag 3
Welke naam hoort bij deze indeling?
Afbeelding: afbeeldingen/ztype.jpg (ook zichtbaar bij de interactieve vraag).
A. Duplex
B. Bungalow
C. Z-type

## Vraag 4
Een duplexwoning en een drive-inwoning zijn niet hetzelfde. Leg beide uit.

# Antwoorden en uitleg

## Vraag 1
C. Suitetype
Je ziet een voor- en achterkamer met een scheiding ertussen. Dat is het suitetype. Bron: afbeelding 7a, p. 2.8.

## Vraag 2
A. Doorzontype
De woonkamer loopt van voor naar achter door. Bron: afbeelding 7b, p. 2.8.

## Vraag 3
C. Z-type
De keuken ligt diagonaal ten opzichte van de entree; de woonruimte loopt ertussen. Bron: afbeelding 7c, p. 2.8.

## Vraag 4
Een duplexwoning is tijdelijk verdeeld in een beneden- en bovenwoning voor twee gezinnen en kan later weer één woning worden. Een drive-inwoning heeft een ingebouwde garage; de naam gaat over die indeling, niet over het aantal gezinnen.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
