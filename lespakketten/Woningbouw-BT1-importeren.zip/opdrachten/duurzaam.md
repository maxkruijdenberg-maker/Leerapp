# Opdrachten — 06 • Duurzaam, passief, NOM en autarkisch

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Waarop kijkt DUBO?
A. Alleen naar het slopen
B. Naar plannen, bouwen, gebruiken én slopen
C. Alleen naar de kleur van zonnepanelen

## Vraag 2
Een woning wekt op jaarbasis evenveel energie op als ze gebruikt. Welke term past?
A. NOM
B. Portiek
C. Souterrain

## Vraag 3
Welke woning moet ook zelf water en afvalwater regelen als externe voorzieningen ontbreken?
A. Een autarkische woning
B. Iedere doorzonwoning
C. Iedere NOM-woning

## Vraag 4
Leg het verschil tussen een passiefhuis en een levensloopgeschikte woning uit.

# Antwoorden en uitleg

## Vraag 1
B. Naar plannen, bouwen, gebruiken én slopen
Duurzaam bouwen gaat over de hele levensduur en het beperken van milieuschade.

## Vraag 2
A. NOM
NOM is nul-op-de-meter: de jaarlijkse energiebalans staat centraal.

## Vraag 3
A. Een autarkische woning
Autarkisch betekent onafhankelijk van externe nutsvoorzieningen. NOM zegt dat niet automatisch.

## Vraag 4
Een passiefhuis heeft vooral een zeer kleine verwarmingsbehoefte door onder andere isolatie en weinig luchtlekken. Een levensloopgeschikte woning kan zonder grote verbouwing blijven passen bij ouder worden, ziekte of een beperking.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
