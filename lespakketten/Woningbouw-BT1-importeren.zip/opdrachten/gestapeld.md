# Opdrachten — 04 • Galerij, maisonette, corridor en toren

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Je loopt door een gemeenschappelijke gang binnen naar je voordeur. Welke vorm past hierbij?
A. Corridorflat
B. Galerijwoning
C. Vrijstaande woning

## Vraag 2
Wat maakt een woning een maisonette?
A. De woning heeft verplicht een garage
B. Er zijn altijd twaalf verdiepingen
C. De woning heeft zelf meerdere verdiepingen met een binnentrap

## Vraag 3
Wat is meetniveau in de aangeleverde uitleg?
A. De hoogte van het hoogste balkon
B. De hoogte van het dak
C. De terreinhoogte bij de ingang

## Vraag 4
Noem twee voordelen en twee nadelen van een galerijwoning uit het boek.

# Antwoorden en uitleg

## Vraag 1
A. Corridorflat
Een corridor is een centrale gang binnen. Een galerij ligt buiten.

## Vraag 2
C. De woning heeft zelf meerdere verdiepingen met een binnentrap
Het gaat om de verdiepingen binnen één woning, bijvoorbeeld wonen beneden en slapen boven.

## Vraag 3
C. De terreinhoogte bij de ingang
Hoogtes worden in deze uitleg vergeleken met het terrein bij de ingang.

## Vraag 4
Voordelen: alle kamers op één woonlaag, eenvoudige bouw of efficiënt gebruik van liften. Nadelen: inkijk/geluid aan de galerij, buiten naar de voordeur lopen, afstand tot de grond, aandacht voor oriëntatie of een onpersoonlijke omgeving. Twee van elk zijn voldoende.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
