# Opdrachten — 10 • Van Wro en bestemmingsplan naar Omgevingswet

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Welke datum hoort bij de invoering van de Omgevingswet in het boek?
A. 1 januari 1965
B. 1 januari 1902
C. 1 januari 2024

## Vraag 2
Waarom is het omgevingsplan breder dan een bestemmingsplan?
A. Het geldt alleen voor grote steden
B. Het gaat alleen over verkoopprijzen
C. Het bevat ook regels over andere aspecten van de fysieke leefomgeving

## Vraag 3
Wat betekent participatie in deze context?
A. Alleen de aannemer kiest
B. Niemand buiten de gemeente mag reageren
C. Betrokkenen kunnen meedenken en belangen inbrengen

## Vraag 4
Leg in eenvoudige taal uit waarom de overheid regels over ruimte, water en milieu samen wil bekijken.

# Antwoorden en uitleg

## Vraag 1
C. 1 januari 2024
De bron plaatst de vervanging van onder andere Wro en Wabo op 1 januari 2024.

## Vraag 2
C. Het bevat ook regels over andere aspecten van de fysieke leefomgeving
Naast grondgebruik en bouwen kunnen bijvoorbeeld milieu, water en erfgoed erin geregeld zijn.

## Vraag 3
C. Betrokkenen kunnen meedenken en belangen inbrengen
Participatie gaat over het betrekken van mensen en organisaties bij plannen en besluiten.

## Vraag 4
Een bouwplan heeft meerdere gevolgen tegelijk. Door ruimte, water, milieu en andere belangen samen te bekijken, kan de overheid een samenhangende afweging maken in plaats van ieder onderwerp los te behandelen.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
