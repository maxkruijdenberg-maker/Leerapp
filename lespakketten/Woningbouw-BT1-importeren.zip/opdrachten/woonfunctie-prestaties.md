# Opdrachten — 14 • Woonfunctie, maten en prestatie-eisen

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Welke drie maten noemt p. 2.28 voor een verblijfsruimte?
A. 55 m², 3 m breed en 1,5 m hoog
B. 18 m², 10 m breed en 4 m hoog
C. 5 m², 1,8 m breed en 2,60 m hoog

## Vraag 2
Welk percentage noemt p. 2.30 bij verblijfsgebied ten opzichte van gebruiksoppervlak?
A. 18%
B. 100%
C. 55%

## Vraag 3
Wat hoort bij een prestatie-eis?
A. Een grenswaarde en een bepalingsmethode
B. Alleen een productnaam
C. Alleen een persoonlijke voorkeur

## Vraag 4
Wat kan een NPR of NTR praktisch helpen doen?

# Antwoorden en uitleg

## Vraag 1
C. 5 m², 1,8 m breed en 2,60 m hoog
Dit zijn de drie genoemde minima in deze lesstof. De toepassingscontext blijft van belang.

## Vraag 2
C. 55%
De bron noemt minimaal 55%. Dit is een bronvraag, geen complete beoordeling van een echt bouwplan.

## Vraag 3
A. Een grenswaarde en een bepalingsmethode
Je moet weten wat de grens is én hoe je vaststelt of eraan wordt voldaan.

## Vraag 4
Een NPR of NTR geeft praktische uitwerkingen of voorbeelden om aan prestatie-eisen te voldoen. Daardoor hoef je bij een bekende oplossing niet alles opnieuw te meten of te berekenen.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
