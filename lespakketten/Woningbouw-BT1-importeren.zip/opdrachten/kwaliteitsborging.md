# Opdrachten — 15 • Wkb, kwaliteitsborger en bruidsschat

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Wat is het doel van een borgingsplan?
A. Risico’s en de manier van controleren vastleggen
B. Alle regels schrappen
C. De verkoopadvertentie schrijven

## Vraag 2
Waarover gaat een gevolgklasse in de uitleg?
A. Alleen de kans dat een woning verkocht wordt
B. Alleen de leeftijd van een koper
C. De ernst van de gevolgen als iets misgaat

## Vraag 3
Welke uitspraak past bij de rol van de gemeente bij kwaliteitsborging?
A. De gemeente verkoopt alle woningen
B. De gemeente heeft nooit meer een taak
C. De gemeente houdt onder andere taken rond het omgevingsplan en handhaving

## Vraag 4
Waarom is er bij de overgang naar de Omgevingswet een bruidsschat van regels?

# Antwoorden en uitleg

## Vraag 1
A. Risico’s en de manier van controleren vastleggen
Het borgingsplan beschrijft hoe risico’s worden beheerst en hoe de controle plaatsvindt.

## Vraag 2
C. De ernst van de gevolgen als iets misgaat
Gevolgklasse gaat over de gevolgen; dat is niet hetzelfde als alleen de kans op een probleem.

## Vraag 3
C. De gemeente houdt onder andere taken rond het omgevingsplan en handhaving
Private technische kwaliteitscontrole betekent niet dat publieke taken verdwijnen.

## Vraag 4
Om regels te laten doorwerken wanneer taken en regels naar gemeenten overgaan. Zo ontstaat niet ineens een situatie zonder regels. Gemeenten kunnen die regels binnen het nieuwe stelsel aanpassen.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
