# Opdrachten — 08 • De Woningwet en de oude situatie

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Wanneer trad de Woningwet uit 1901 in werking?
A. 1902
B. 1901
C. 2024

## Vraag 2
Wat betekent de beschreven zorgplicht?
A. Alleen letten op de verkoopprijs
B. Een eigenaar hoeft nooit onderhoud te doen
C. Geen gevaar voor gezondheid of veiligheid laten ontstaan of voortbestaan

## Vraag 3
Wat is bestuursdwang in de beschreven situatie?
A. De overheid laat ingrijpen en kan de kosten op de eigenaar verhalen
B. De koper bepaalt de huur
C. Een vrijwillige woningbezichtiging

## Vraag 4
Noem drie problemen waarvoor de vroege Woningwet een oplossing moest helpen bieden.

# Antwoorden en uitleg

## Vraag 1
A. 1902
Het onderscheid is: wet uit 1901, in werking vanaf 1902.

## Vraag 2
C. Geen gevaar voor gezondheid of veiligheid laten ontstaan of voortbestaan
De toestand van het gebouw mag geen gevaar opleveren. De zorgplicht is dus meer dan alleen een wens voor comfort.

## Vraag 3
A. De overheid laat ingrijpen en kan de kosten op de eigenaar verhalen
Als noodzakelijk herstel niet wordt uitgevoerd, kan de gemeente maatregelen laten uitvoeren op kosten van de eigenaar.

## Vraag 4
Bijvoorbeeld te kleine woningen, slechte sanitaire voorzieningen, weinig daglicht, weinig frisse lucht of een slechte ligging. Drie problemen zijn voldoende.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
