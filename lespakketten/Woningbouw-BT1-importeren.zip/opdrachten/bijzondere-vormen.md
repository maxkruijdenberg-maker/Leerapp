# Opdrachten — 05 • Andere woonvormen en domotica

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Wat is een penthouse?
A. Een kelderwoning
B. Een appartement boven in een flatgebouw
C. Een vrijstaand huis met tuin

## Vraag 2
Wat verspringt bij een split-levelwoning?
A. De vloerniveaus, ongeveer een halve verdieping
B. Alleen de erfgrens
C. De ligging van de wijk

## Vraag 3
Wat hoort bij domotica?
A. Alleen het metselen van muren
B. Elektronische toepassingen voor bijvoorbeeld veiligheid en energieregeling
C. Alleen de dakvorm

## Vraag 4
Hoe combineert een kangoeroewoning hulp en privacy?

# Antwoorden en uitleg

## Vraag 1
B. Een appartement boven in een flatgebouw
Een penthouse ligt boven in een gebouw en heeft vaak een groot dakterras.

## Vraag 2
A. De vloerniveaus, ongeveer een halve verdieping
De vloeren liggen niet allemaal op dezelfde volledige verdiepingshoogtes.

## Vraag 3
B. Elektronische toepassingen voor bijvoorbeeld veiligheid en energieregeling
Domotica combineert toepassingen in huis, bijvoorbeeld een alarmsysteem of energieregeling.

## Vraag 4
Generaties wonen dichtbij elkaar en kunnen elkaar helpen. Ze hebben tegelijk eigen woonruimte. De hoofdwoning en het andere deel zijn bijvoorbeeld met een deur of hal verbonden.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
