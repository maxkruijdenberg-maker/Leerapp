# Opdrachten — 07 • Wie maakt regels en wat betekenen de woorden?

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Welke uitspraak klopt?
A. Elk bouwwerk is een gebouw
B. Een gebouw heeft nooit muren
C. Elk gebouw is een bouwwerk

## Vraag 2
Wat betekent amoveren?
A. Een verdieping toevoegen
B. Geheel of gedeeltelijk afbreken
C. Een vergunning aanvragen

## Vraag 3
Wat beschrijft een norm onder andere?
A. Eisen of meet-, reken- en beproevingsmethoden
B. De verkoopprijs van ieder huis
C. Wie in een wijk woont

## Vraag 4
Een constructie is wel een bouwwerk, maar geen gebouw. Hoe kan dat?

# Antwoorden en uitleg

## Vraag 1
C. Elk gebouw is een bouwwerk
Gebouw is een specifiek soort bouwwerk: toegankelijk voor mensen, overdekt en met gehele of gedeeltelijke omsluiting.

## Vraag 2
B. Geheel of gedeeltelijk afbreken
Amoveren is een ander woord voor slopen.

## Vraag 3
A. Eisen of meet-, reken- en beproevingsmethoden
Een norm biedt technische eisen of methoden. Een kwaliteitsverklaring is een vorm van bewijs.

## Vraag 4
Niet ieder bouwwerk is overdekt, met muren omsloten en toegankelijk voor mensen. Een constructie kan aan de omschrijving van bouwwerk voldoen zonder aan alle kenmerken van een gebouw te voldoen.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
