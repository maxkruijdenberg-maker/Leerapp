# Opdrachten — 12 • Gebruiksfunctie, gebied en ruimte

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Wat staat centraal in een verblijfsgebied?
A. Het verblijf van mensen
B. Alleen de opslag van technische apparatuur
C. De verkoop van het perceel

## Vraag 2
Welke combinatie hoort bij elkaar?
A. Iedere verkeersruimte is een bedgebied
B. Functieruimte ligt altijd buiten een gebouw
C. Bedruimte ligt in een bedgebied

## Vraag 3
Kan één gebouw meerdere gebruiksfuncties hebben?
A. Nee, nooit
B. Ja, bijvoorbeeld kantoor en bijeenkomst
C. Alleen als het vrijstaand is

## Vraag 4
Leg het verschil uit tussen verblijfsgebied en verblijfsruimte.

# Antwoorden en uitleg

## Vraag 1
A. Het verblijf van mensen
De naam verblijfsgebied verwijst naar het beoogde verblijf van mensen.

## Vraag 2
C. Bedruimte ligt in een bedgebied
Bedruimte is de afzonderlijke ruimte; bedgebied is het bijbehorende gebied.

## Vraag 3
B. Ja, bijvoorbeeld kantoor en bijeenkomst
De gebruiksfunctie volgt het gebruik van delen van het gebouw; er kunnen meerdere functies in één gebouw zijn.

## Vraag 4
Een verblijfsgebied is een gedeelte bedoeld voor het verblijf van mensen. Het kan worden ingedeeld in ruimten. Een verblijfsruimte is zo’n afzonderlijke ruimte binnen dat gebied.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
