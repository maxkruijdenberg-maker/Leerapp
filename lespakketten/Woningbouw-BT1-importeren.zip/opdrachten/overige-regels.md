# Opdrachten — 16 • Arbeid, bodem, bomen, leges en water

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Waarvoor is het Arbobesluit Bouwproces bedoeld?
A. Alleen het bepalen van huurprijzen
B. Alleen het kiezen van een gevelkleur
C. Veilig en gezond werken in en rond het bouwproces

## Vraag 2
Wat zijn leges?
A. Boetes voor iedere verhuizing
B. Kosten van de hypotheekrente
C. Bedragen voor overheidsdiensten zoals behandeling van een vergunningaanvraag

## Vraag 3
Je wilt een leiding door een dijk leggen. Welke instantie kan daarvoor toestemming moeten geven?
A. Alleen de makelaar
B. Het waterschap
C. Alleen de bewonersvereniging

## Vraag 4
Waarom kan het ophogen van een tuin met aangevoerde grond met bodemregels te maken hebben?

# Antwoorden en uitleg

## Vraag 1
C. Veilig en gezond werken in en rond het bouwproces
Arbeidsomstandigheden spelen al bij ontwerp en later ook bij uitvoering en onderhoud.

## Vraag 2
C. Bedragen voor overheidsdiensten zoals behandeling van een vergunningaanvraag
De gemeente legt haar tarieven vast in de legesverordening.

## Vraag 3
B. Het waterschap
Een dijk is een waterkering. Het waterschap kan hiervoor regels en toestemmingsvereisten hebben.

## Vraag 4
De aangevoerde grond wordt op of in de bodem toegepast. Die toepassing mag niet tot ongewenste bodemvervuiling leiden. Het boek behandelt dit bij het Besluit bodemkwaliteit.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
