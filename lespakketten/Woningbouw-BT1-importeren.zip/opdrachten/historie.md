# Opdrachten — 01 • Hoe woningbouw veranderde

Beantwoord eerst zonder naar de oplossingen onderaan te kijken.

## Vraag 1
Waarom bouwden bedrijven zoals Philips woningen voor hun werknemers?
A. Om personeel aan het bedrijf te binden
B. Om alle huizen te verkopen als kantoor
C. Omdat etagewoningen verboden waren

## Vraag 2
Wat is een beletage in de beschreven woningvorm?
A. Een woonlaag ongeveer een meter boven straatniveau
B. Een kamer onder de trap
C. Een berging op zolder

## Vraag 3
Wat was een nadeel van de beschreven oude etagewoningen?
A. Trappen waren niet altijd gescheiden van de woningen
B. Er waren altijd te veel liften
C. Elke woning had een eigen tuin

## Vraag 4
Leg het verschil uit tussen een tuindorp en een portiek.

# Antwoorden en uitleg

## Vraag 1
A. Om personeel aan het bedrijf te binden
Het bedrijf bood huisvesting en maakte het daarmee aantrekkelijker om er te blijven werken.

## Vraag 2
A. Een woonlaag ongeveer een meter boven straatniveau
De beletage ligt verhoogd, vaak boven een souterrain.

## Vraag 3
A. Trappen waren niet altijd gescheiden van de woningen
Het boek noemt onder andere niet-afgescheiden trappen en slapen in bedsteden of alkoven.

## Vraag 4
Een tuindorp is een woonwijk met een dorps karakter. Een portiek is een gezamenlijke toegang of buitenportaal bij woningen. Het ene gaat over een wijk, het andere over de toegang tot woningen.
Vergelijk jouw antwoord met het voorbeeldantwoord. De betekenis telt; je hoeft niet precies dezelfde woorden te gebruiken.
