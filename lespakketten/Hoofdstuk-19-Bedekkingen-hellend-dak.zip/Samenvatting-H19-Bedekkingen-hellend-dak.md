# Hoofdstuk 19 – Bedekkingen hellend dak

## Dakhelling en waterafvoer

De **dakbedekking** beschermt het dak tegen regen en andere weersinvloeden. De **dakondergrond**, bijvoorbeeld houten dakbeschot, draagt de bedekking en biedt een basis voor de bevestiging. De **dakhelling** bepaalt mede hoe snel regen afloopt. Bij een **schubvormige bedekking** liggen de delen over elkaar. Het water loopt van de hoger gelegen delen op de lager gelegen delen. Hoe kleiner de helling, hoe belangrijker de juiste overlap en onderdakopbouw worden. De geschikte helling, overlap en bevestiging hangen af van het product, de blootstelling en het daksysteem.

De **nok** is de bovenste aansluiting tussen dakvlakken. Een **hoekkeper** is een uitwendige hoek. Een **kilkeper** is een inwendige hoek waarin water uit twee dakvlakken samenkomt. Ook bij een **dakdoorbreking**, zoals een schoorsteen, moet het water om de opening heen worden geleid. Een daarvoor geschikte **onderdakfolie** kan water dat onder de bedekking komt afvoeren naar de dakvoet. De folie en aansluitingen moeten passen bij de vochthuishouding van de hele dakopbouw.

## Leien, shingles en riet

**Natuurleien** zijn dunne platen van gespleten leisteen. Ze worden overlappend gelegd en vastgezet met geschikte nagels of **leihaken**. Bij **enkele dekking** overlapt een lei de direct onderliggende rij en sluiten de delen ook zijwaarts overlappend aan. Bij **dubbele dekking** overlapt een rij ook de rij twee lagen lager. De wijze van dekken bepaalt hoe de voegen tegen inregenen zijn beschermd. **Leipannen** lijken op leien maar zijn gevormde producten, bijvoorbeeld van keramiek of beton. **Bitumenshingles** bestaan uit met bitumen behandeld glasvlies, meestal met een beschermende korrellaag. Ze worden in overlappende rijen op een geschikt beschot bevestigd. **Houten shingles** zijn losse houten delen die eveneens overlappend worden gelegd.

Op een **rieten dak** loopt water langs de stengels naar beneden en weer naar buiten. Helling, laagopbouw en bevestiging helpen voorkomen dat water te ver doordringt. Bij een traditionele **open rietconstructie** ligt het riet op latten. Bij een **schroefdak** wordt het riet aan een gesloten ondergrond bevestigd. Die systemen verschillen in luchtstroming, droging en brandgedrag. De brandveiligheid hangt af van de volledige opbouw en de eisen voor het gebouw.

## Metaal en plaatbedekkingen

**Zink** en **koper** worden vaak in banen gelegd. Een **staande felsnaad** verbindt de opstaande randen van twee banen door ze in elkaar te vouwen. Een **roefverbinding** vormt een verhoogde naad over een lat, afgedekt met een metalen kap. **Klangen** zijn bevestigingsclips. Het systeem moet de banen vasthouden en tegelijk rekening houden met **thermische uitzetting** en krimp. **Lood** werd gebruikt voor vervormbare aansluitingen. Waar passend kan een geschikte loodvervanger de belasting van het milieu door uitspoeling van lood beperken.

**Geprofileerde platen** ontlenen stijfheid aan golven of ribben. Ze zijn er onder meer in staal, aluminium, vezelcement en kunststof. De naden, overlappen en bevestigingen moeten passen bij de dakhelling en het plaatsingssysteem. Doorschijnende platen en **dakbeglazing** kunnen daglicht toelaten. Bij dakbeglazing moet de aansluiting tussen glas en draagprofielen regen weren en afvoeren. Een **sandwichplaat** combineert metalen deklagen met een isolerende kern. De aansluitingen tussen platen en rondom doorbrekingen blijven bepalend voor de werking van het dak.
