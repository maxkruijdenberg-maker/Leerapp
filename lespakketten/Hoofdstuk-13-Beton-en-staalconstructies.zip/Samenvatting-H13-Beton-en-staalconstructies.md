# Hoofdstuk 13 – Beton- en staalconstructies

## Betonspecie en verharding

**Betonspecie** is het verse mengsel van cement, water, zand en grof toeslagmateriaal zoals grind. Het cement reageert met water en vormt **cementsteen**, die de korrels bindt. De **water-cementfactor** is de massa water gedeeld door de massa cement, beide in kilogram. Tel ook het vocht in zand en grind mee. Extra water maakt de specie vaak makkelijker te verwerken, maar kan na verharding meer poriën en een lagere druksterkte geven. Een geschikt **plastificeermiddel** kan de verwerkbaarheid verbeteren zonder extra water toe te voegen.

De **consistentie** geeft aan hoe stijf of vloeibaar de verse specie is. Bij de **zetmaatproef** meet je hoeveel de specie inzakt nadat een kegelvorm is opgetild. **Verdichten**, bijvoorbeeld met een trilnaald, verwijdert ingesloten lucht en helpt de specie de mal te vullen. **Nabehandeling** beschermt het jonge beton tegen te snel uitdrogen, zodat de verhardingsreactie kan doorgaan. De **sterkteklasse** geeft de druksterkte aan waarmee wordt gerekend. De **milieuklasse** beschrijft de blootstelling, bijvoorbeeld aan vorst of dooizout. Proefstukken kunnen na verharding op druksterkte worden beproefd.

## Gewapend en voorgespannen beton

Beton kan goed tegen **druk** en veel minder goed tegen **trek**. Bij **gewapend beton** neemt het betonstaal vooral trekkrachten op. Bij een eenvoudig opgelegde balk met een neerwaartse belasting ligt de trekzone midden in de overspanning aan de onderkant. Bij andere opleggingen of belastingen kan de trekzone anders liggen. De constructeur bepaalt waar de wapening nodig is. **Voorspanning** brengt het beton vooraf onder druk en beperkt zo trekspanningen en scheurvorming door gebruiksbelasting. Bij **voorspannen met voorgerekt staal** worden de kabels vóór het storten gespannen. Bij **naspanbeton** worden ze aangespannen nadat het beton voldoende is verhard.

De **bekisting** geeft verse specie vorm en draagt de belasting tijdens het storten. **Afstandhouders** houden het staal op afstand van de bekisting. Zo ontstaat **betondekking**, de afstand van het betonoppervlak tot de dichtstbijzijnde wapening. De dekking beschermt het staal en helpt bij de brandwerendheid. De vereiste dekking volgt uit het ontwerp en de blootstelling. Bij **wapeningscorrosie** kan het roestende staal uitzetten, waardoor beton scheurt of afspringt. Onvoldoende verdichting kan **grindnesten** veroorzaken: plekken met veel grove korrels en open ruimten. **Prefab beton** wordt vooraf gemaakt en op de bouwplaats gemonteerd. De aansluitingen moeten de krachten tussen de onderdelen veilig kunnen overdragen.

## Staalconstructies en verbindingen

Een **ligger** overspant een opening en draagt belasting naar zijn opleggingen. Een **kolom** voert belastingen vooral in de lengterichting af. Een **portaal** bestaat uit kolommen met een ligger. Via de **voetplaat** en de plaatselijke aansluiting gaat de belasting van de kolom naar de onderconstructie, bijvoorbeeld een fundering. **Ankers** verbinden de voetplaat met het beton.

Bij een **boutverbinding** worden stalen delen mechanisch verbonden. Bij een **lasverbinding** smelten de delen plaatselijk samen. Een in de berekening **scharnierende verbinding** laat draaiing toe en draagt krachten over zonder dat op overdracht van buigend moment wordt gerekend. Een **momentvaste verbinding** remt die draaiing en draagt ook een **buigend moment** over, de belasting die een onderdeel wil laten buigen. Het ontwerp van de aansluiting bepaalt het gedrag. Een **windverband** met diagonalen vormt driehoeken en helpt horizontale krachten af te voeren. Tijdens montage kunnen tijdelijke **schoren** nodig zijn om de constructie stabiel te houden.

Staal is onbrandbaar, maar verliest bij hoge temperatuur sterkte en stijfheid. **Brandwerende bescherming**, zoals platen, spuitmortel of een geschikte opschuimende verf, vertraagt het opwarmen van kolommen en liggers. Ook aansluitingen en doorvoeren vragen aandacht.
