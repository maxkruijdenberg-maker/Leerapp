# Woningbouw en bouwwetgeving

Eén deelonderwerp met 16 korte hoofdstukjes.



# Start hier • uitleg en bronafbakening

# Zo gebruik je dit pakket
Dit is jouw hoofdstuk in eenvoudige taal. De officiële woorden blijven staan. Meteen daarna lees je wat ze betekenen. Er zijn geen grappen toegevoegd.

## Wat zit erin?
Werk de hoofdstukjes hieronder op volgorde door. Lees steeds een klein stukje. Leg daarna zonder te kijken uit wat het betekent. Maak de vragen. Lees ook bij een goed antwoord de uitleg. Bewaar de onderwerpstoets voor het einde.

## Waarop is de uitleg gebaseerd?
Op de 30 foto’s uit jouw Fotos.zip: pagina’s 2.2–2.6, 2.8–2.14 en 2.16–2.33. Pagina’s 2.1, 2.7 en 2.15 zijn niet als volledige pagina aangeleverd. Van wat daarop staat is dus geen volledige samenvatting gemaakt. De originele boekfoto’s zijn voor deze kleinere download weggelaten. De drie oefenplattegronden blijven beschikbaar.

Dit is een samenvatting en uitleg van jouw boek, geen letterlijke kopie en geen actualisering van wetgeving. Historische regels worden als historisch uitgelegd. Concrete getallen en voorwaarden uit het boek gelden in de context van die bron; maak er geen algemene regel voor ieder gebouw van.

## Let op bij enkele formuleringen in het boek
De bron bevat uitspraken die context of controle bij je opleiding vragen. Ze zijn niet stilzwijgend vervangen door andere regels:
- Pagina 2.11 noemt een lift bij een woonfunctievloer boven 3 meter boven meetniveau. Leer ook wat meetniveau betekent; laat de precieze toepassingsvoorwaarden toelichten.
- Pagina 2.25 noemt 2029 als overgangstermijn voor het omgevingsplan. Dit pakket controleert niet of die termijn nog actueel is.
- Pagina 2.29 koppelt een afwijkende oppervlaktemeting aan de onderzoeksplicht van de koper. Behandel dit niet als een volledige uitleg van alle rechten van een koper.
- Pagina 2.30 maakt een onderscheid tussen een drijvende woning en een woonschip/woonark. De juridische toepassing vraagt context.
- Pagina 2.31 noemt KOMO/BRL in de uitleg over toegelaten instrumenten voor kwaliteitsborging. Laat het verschil tussen verklaring, richtlijn en instrument uitleggen.
- Pagina 2.32 legt de 5%-regeling bij de notaris kort uit. Het boek geeft hier geen volledige behandeling van alle voorwaarden en termijnen.
Deze punten staan niet als ongenuanceerde goed/fout-vragen in de toets.

## Over de toets
Er is geen examen-PDF bij deze bron aangeleverd. De vragen controleren daarom de behandelde boekstof. Het is een oefentoets, geen officiële NVMIO-examentoets. Open vragen kijk je zelf na met het voorbeeldantwoord. Er zijn geen video’s in dit pakket.



# 01 • Hoe woningbouw veranderde

# Waarom kwamen er andere woningen?
In de negentiende eeuw wilden particulieren en vakbonden betere woningen voor arbeiders. Ze richtten **woningbouwverenigingen** op. De huur moest passen bij het loon én de kosten dekken. Het ging dus niet alleen om liefdadigheid.

Het boek noemt Amsterdam (1851), Arnhem (1853), Den Haag en Utrecht (1854) en het Agnetapark in Delft (1884). Ook kerken bouwden voor hun eigen gemeenschap. Bedrijven bouwden woningen om personeel aan zich te binden. Voorbeelden zijn Philipsdorp in Eindhoven en Gerodorp in Zeist. Zo’n wijk met een dorps karakter en aandacht voor de woonomgeving heet een **tuindorp**.

## Woningen boven elkaar
Een **etagewoning** is een woning op een verdieping in een gebouw met meerdere woningen. In Nederland kwam deze vorm in de negentiende eeuw op. Tot 1940 vooral in Amsterdam, Rotterdam en Den Haag.

In de oude indeling had de voorwoning op de begane grond een eigen straatdeur. Een andere deur gaf toegang tot de achterwoning en de trap naar boven. Op een woonlaag konden meerdere gezinnen wonen. Op zolder lagen soms slaapkamers voor bewoners van de lagere verdiepingen.

Die oude woningen hadden nadelen. Mensen sliepen vaak in **bedsteden** of **alkoven**: ingebouwde slaapplaatsen of tussenkamers. Trappen waren niet altijd gescheiden van de woningen. Het boek noemt dat deze situatie in Rotterdam tot 1939 werd toegestaan.

Een **souterrain** is een bouwlaag die deels onder straatniveau ligt. Ligt de woonlaag daarboven ongeveer een meter boven de straat, dan heet die **beletage**.

## Portiek
Eind negentiende eeuw kwamen in Den Haag portiekwoningen. Benedenwoningen hadden een eigen deur. De deuren van bovenwoningen lagen bij elkaar aan een buitenportaal op de eerste verdieping: het **portiek**.

**Bron:** aangeleverde LOI-foto’s, p. 2.2, p. 2.3, p. 2.4, p. 2.5.


# 02 • Vrijstaand, rijwoning en woongebouw

# Eerst het verschil tussen een huis en een woongebouw
Bij een **eengezinswoning** hoort de woning als geheel bij één huishouden. Bij **meergezinsbouw** zitten meerdere afzonderlijke woningen in een gebouw.

Het boek gebruikt deze indeling:
- **Laagbouw:** twee of drie woonlagen, bijvoorbeeld begane grond, verdieping en eventueel zolder.
- **Etagebouw of middelhoogbouw:** drie of vier woningen boven elkaar.
- **Hoogbouw:** vier of meer woningen boven elkaar; een afzonderlijke woning heeft meestal één woonlaag.
Vier komt in beide laatste omschrijvingen voor. De indeling in deze tekst heeft dus een overlap; verzin daar geen harde extra grens bij.

Een **woongebouw** bevat volgens de hier gebruikte Bbl-omschrijving twee of meer woningen die via een gemeenschappelijke verkeersroute bereikbaar zijn. Denk aan een gedeelde gang of trap. Het Bbl kijkt of een woonfunctie wel of niet in zo’n woongebouw ligt.

## Vrijstaand en in een rij
Een **vrijstaande woning** staat los. Het boek noemt onder andere bungalow, villa en landhuis. Een bungalow heeft meestal één bouwlaag en een plat dak. Vrijstaande woningen komen ook voor in forensen- of slaapgemeenten. Bewoners wonen daar, maar reizen voor hun werk naar een andere plaats.

Een **rijwoning** maakt deel uit van een rij van minimaal drie aaneengebouwde woningen. De plattegronden kunnen gelijk of gespiegeld zijn. Deze bouw is meestal goedkoper dan losse of dubbele woningen. Een nadeel bij een tussenwoning kan de bereikbaarheid van de achterkant zijn.

Woningen worden gemaakt voor verschillende groepen: gezinnen, starters, alleenstaanden, studenten, groepen en oudere bewoners die zelfstandig wonen, eventueel met zorg. De doelgroep en het woningtype zijn verschillende dingen: een woningvorm zegt niet automatisch wie er mag wonen.

**Bron:** aangeleverde LOI-foto’s, p. 2.6.


# 03 • Herken de indeling van een woning

# De naam vertelt iets over de indeling
Een **duplexwoning** ontstond als oplossing voor woningnood na de Tweede Wereldoorlog. Een eengezinswoning werd tijdelijk geschikt gemaakt voor twee gezinnen. Achter de voordeur zat een portaal met twee toegangen: één naar beneden en één naar boven. Later kon het weer één woning worden. Duplex betekent tweevoudig.

Bij het **suitetype** zijn de voor- en achterkamer gescheiden door één of twee schuifdeuren. Dit kwam veel voor tussen de wereldoorlogen. De voorkamer was zitkamer, de achterkamer woonkamer.

Een **doorzonwoning** heeft een doorlopende woonkamer van voor naar achter. Deze variant op het suitetype werd na de Tweede Wereldoorlog veel gebouwd. De bouw is economisch aantrekkelijk. Het boek noemt als nadelen een vrij eenvormige indeling, inkijk door het huis en vaak het ontbreken van een deur naar de tuin.

Bij het **Z-type** ligt de keuken schuin tegenover de entree. De indeling geeft minder hinderlijke doorkijk en meer mogelijkheden om activiteiten te combineren. Een nadeel: de route van keuken naar entree loopt door de woonruimte. Dit type zie je veel uit de jaren zestig en zeventig.

## Schakelen en inrijden
**Schakelwoningen** kunnen via een garage of berging met elkaar verbonden zijn. De hoofdwoningen delen dan geen bouwmuur. Bij gekoppelde dubbele woningen kan juist wel een gemeenschappelijke bouwmuur voorkomen: een **mandelige muur**. **Stichtingskosten** zijn de kosten om het bouwproject tot stand te brengen; het boek noemt hogere stichtingskosten bij de beschreven schakelvorm.

Een **drive-inwoning** heeft een ingebouwde garage. De eerste Nederlandse voorbeelden uit de tekst staan in Amsterdam, 1936. Er zijn twee of drie bouwlagen. In de afgebeelde variant liggen garage en tuinkamer beneden, woonkamer en keuken erboven en slaapkamers nog een verdieping hoger. Een praktijk aan huis kan alleen als onder andere het omgevingsplan dat toelaat.

Een rij hoeft niet overal hetzelfde te zijn. Variatie kan zitten in perceelbreedte, verspringende perceelsgrenzen of gevels, de plaats van bergingen en de dakvorm.

**Bron:** aangeleverde LOI-foto’s, p. 2.8, p. 2.9, p. 2.10.


# 04 • Galerij, maisonette, corridor en toren

# Hoe kom je bij de voordeur?
Bij etagebouw worden woningen gestapeld om met ruimte en kosten om te gaan. Een trappenhuis met bordessen kan bijvoorbeeld zes tot acht woningen ontsluiten. Bij de gemeenschappelijke ingang zitten vaak brievenbussen en een afsluitbare deur. Bergingen en garages kunnen op de begane grond of in het souterrain liggen.

Liften kwamen rond 1930 in beeld en werden na 1960 breder toegepast in sociale woningbouw. **Meetniveau** is hier de hoogte van het terrein bij de ingang. De bron koppelt een lifteis aan een woonfunctievloer hoger dan drie meter boven dat niveau; zie de bronnotitie bij Start hier voor de toepassingsvoorwaarden.

## Vier belangrijke vormen
- **Galerijwoning:** bereikbaar via een gemeenschappelijke loopstrook buiten. Meestal liggen alle kamers op één woonlaag. Aan de andere kant ligt vaak een balkon. Voordelen: eenvoudig bouwen, alles gelijkvloers en efficiënt gebruik van liften. Nadelen: inkijk en geluid bij de galerij, afstand tot de grond en minder prettig buiten lopen naar de voordeur. Oriëntatie speelt mee; de tekst noemt de woonkamer liefst op het zuidwesten. Ook verkeer, parkeren en een onpersoonlijke woonomgeving kunnen nadelen zijn.
- **Maisonette:** één woning met wonen en slapen op verschillende verdiepingen, verbonden door een eigen binnentrap. De toegang kan aan een galerij op de woonverdieping liggen. Je kunt het zien als gestapelde woningen die zelf meerdere verdiepingen hebben.
- **Portiekflat:** woningen liggen direct aan een gemeenschappelijk trappenhuis, eventueel met lift. Vaak twee tot vier woningen per verdieping. De toegang is binnen en geeft meer privacy dan een buitenliggende galerij.
- **Corridorflat:** de voordeuren liggen aan een centrale gang binnen. De oriëntatie van de woningen vraagt aandacht. De gang kan onpersoonlijk aanvoelen. De tekst noemt senioren- en studentenhuisvesting als toepassingen.

## Terras en toren
Bij **terraswoningen** kan het dak van een lager deel een dakterras of daktuin zijn. Een **woontoren** biedt veel woningen en soms andere functies op weinig grond. Woningen liggen vaak rond een centrale trap en lift. Beneden kunnen winkels, kantoren of bergingen zitten.

Een toren inpassen vraagt meer dan veel woningen stapelen. Let op menselijke schaal, openbare ruimte, wind, schaduw, privacy, bereikbaarheid, regionale woningvraag en een mix van bewoners en functies. Duurzaamheid en circulariteit spelen ook mee.

**Bron:** aangeleverde LOI-foto’s, p. 2.10, p. 2.11, p. 2.12, p. 2.13, p. 2.14.


# 05 • Andere woonvormen en domotica

# Woningen met een eigen kenmerk
Een **penthouse** is een appartement boven in een flatgebouw. Het is dus geen vrijstaande woning. Kenmerken zijn vaak een ruim dakterras, veel licht, uitzicht en een afwijkend ontwerp. Het boek verbindt de opkomst met de wederopbouw in de jaren vijftig en met latere stedelijke hoogbouw.

Een **patiowoning** is een grondgebonden woning met een binnenplaats of binnentuin. Meestal is er één bouwlaag, maar een verdieping kan ook voorkomen. **Grondgebonden** betekent hier dat de woning direct met het terrein samenhangt.

Bij een **split-levelwoning** liggen vloeren een halve verdieping ten opzichte van elkaar versprongen. Je gaat dus in kortere trapdelen van het ene niveau naar het andere.

Een **seniorenwoning** is aangepast om oudere mensen zelfstandig te laten wonen. Een **kangoeroewoning** combineert woonruimten voor twee of meer generaties onder één dak. Er is een hoofdwoning met een aangebouwd of ingebouwd deel. Een deur of gezamenlijke hal verbindt de delen. Het doel is nabijheid voor hulp én behoud van eigen ruimte en privacy.

## Domotica
**Domotica** is het combineren van elektronische, communicatie- en elektrische toepassingen in en rond huis. Het woord komt van domus (huis) en telematica. Volgens de tekst werd het begrip in Nederland in 1994 geïntroduceerd.

Het gaat bijvoorbeeld om zorg, communicatie, ontspanning, beveiliging, alarmen, toezicht en energieregeling. Daardoor kan een huis comfortabeler en veiliger worden. Voor ouderen en mensen met een beperking kan het helpen om zelfstandig te blijven wonen.

Onthoud het onderscheid: een woningtype gaat over de woning en haar indeling. Domotica gaat over toepassingen die je in die woning gebruikt.

**Bron:** aangeleverde LOI-foto’s, p. 2.16, p. 2.17.


# 06 • Duurzaam, passief, NOM en autarkisch

# Duurzaam bouwen kijkt verder dan de bouwdag
**DUBO** betekent duurzaam bouwen. Je probeert milieuschade te beperken tijdens de hele levensduur: plannen, bouwen, gebruiken en slopen. Het gaat ook om de omgeving en om bijvoorbeeld wegen- en waterbouw. **BENG** staat voor bijna energieneutrale gebouwen; het boek noemt de samenhang met energiezuinige concepten. Deze pagina’s geven geen volledige uitwerking van alle BENG-eisen.

## Drie verschillende begrippen
Een **passiefhuis** beperkt vooral de behoefte aan verwarming. Het heeft zeer goede isolatie en weinig ongewenste luchtverliezen via kieren. Het benut passieve warmte. Het boek beschrijft een ideale situatie waarin centrale verwarming niet nodig is. Als vergelijking noemt het ongeveer 15 kWh per m² tegenover 200 kWh per m² voor verwarming van een woning uit de jaren zestig. Gebruik die cijfers als de vergelijking uit het boek, niet als belofte voor ieder huis. De bouwkosten kunnen hoger zijn; de CO₂-uitstoot lager. Het boek noemt eerste passiefhuisprojecten eind 2008–2009.

**NOM** betekent nul-op-de-meter. Over een jaar wekt de woning evenveel energie op als ze gebruikt. Dat kan met een combinatie van isolatie, installaties en bijvoorbeeld zonnepanelen. NOM kan bij nieuwbouw of renovatie. Voordelen zijn comfort, een lagere energierekening en minder milieubelasting. De tekst noemt **EPV**, energieprestatievergoeding, in de huurcontext.

Een **autarkische woning** is onafhankelijk van externe nutsvoorzieningen zoals elektriciteit, water en riolering. De woning moet bijvoorbeeld zelf energie opwekken, water opvangen en water zuiveren. Denk aan zonnepanelen, windenergie, opslag en filters. Autarkisch gaat dus verder dan alleen een jaarlijkse energiebalans.

## Geschikt blijven als je leven verandert
**Levensloopbestendig**, of liever **levensloopgeschikt**, betekent dat de woning zonder grote verbouwing kan passen bij ouder worden, ziekte of een beperking. Het gaat om bruikbaar blijven tijdens verschillende fasen van het leven.

**Bron:** aangeleverde LOI-foto’s, p. 2.17, p. 2.18.


# 07 • Wie maakt regels en wat betekenen de woorden?

# Waarom bestaan bouwregels?
Regels over bouwen zijn niet nieuw. Vroeger ging het al om brand, hygiëne en het voorkomen van ziekten. Vanaf ongeveer 1900 kwamen uitgebreidere regels door de slechte woonomstandigheden uit de negentiende eeuw. De regels gingen later ook over andere gebouwen, veiligheid, gezondheid, bruikbaarheid, energie en milieu. Ze kunnen gaan over nieuwe én bestaande bouw.

**Publiekrechtelijke regels** zijn regels van de overheid. De tekst noemt het Rijk, provincies, gemeenten en waterschappen. Bij gemeenten voeren **burgemeester en wethouders (B&W)** veel taken uit en handhaven zij regels. Je kunt te maken krijgen met bouw- en woningtoezicht, stedenbouw, een omgevingsdienst en de brandweer.

## Woorden die je uit elkaar moet houden
- **Bouwen:** plaatsen, oprichten, geheel of gedeeltelijk vernieuwen, veranderen of vergroten.
- **Bouwwerk:** een constructie van enige omvang, van bijvoorbeeld hout, steen of metaal, die direct of indirect met de grond verbonden is en bedoeld is om op die plek te functioneren.
- **Gebouw:** een bouwwerk dat mensen kunnen binnengaan, met een dak en geheel of gedeeltelijk omsloten door muren. Elk gebouw is een bouwwerk. Niet elk bouwwerk is een gebouw.
- **Slopen of amoveren:** geheel of gedeeltelijk afbreken.
- **Norm:** een document van een onafhankelijk deskundig instituut. Het geeft eisen of manieren om iets te meten, berekenen of beproeven. NEN-normen hebben een nummer. Oudere normen kunnen vervangen zijn door Europese normen.
- **Kwaliteitsverklaring:** schriftelijk bewijs van een bevoegde onafhankelijke instelling dat een materiaal of onderdeel aan bepaalde eisen voldoet. De tekst noemt onder andere KOMO.

Een norm zegt dus bijvoorbeeld hoe je iets beoordeelt. Een kwaliteitsverklaring kan laten zien dat een product aan bepaalde eisen voldoet. Dat is niet hetzelfde.

**Bron:** aangeleverde LOI-foto’s, p. 2.18, p. 2.19.


# 08 • De Woningwet en de oude situatie

# Goede woningen werden een overheidstaak
Wonen is een basisbehoefte. De overheid wil dat er goede en betaalbare woningen zijn. De **Woningwet** is daarvoor een belangrijk middel.

In de negentiende eeuw waren veel woningen slecht. Denk aan te weinig ruimte, ongunstige ligging, slechte sanitaire voorzieningen en te weinig daglicht of frisse lucht. De Woningwet kwam in **1901** en trad in **1902** in werking.

## Wat moest er toen gebeuren?
De historische regeling liet gemeenten minimumregels vastleggen in een bouwverordening. Er kwamen onder andere:
- regels en vergunningen voor bouwen;
- gemeentelijke controle en handhaving;
- uitbreidingsplannen voor gemeenten met meer dan 10.000 inwoners;
- mogelijkheden om herstel te eisen;
- mogelijkheden om ongeschikte woningen onbewoonbaar te verklaren en te laten ontruimen;
- steun voor sociale woningbouw.

**Bestuursdwang** betekent hier dat de gemeente zelf laat ingrijpen als een vereiste maatregel niet wordt uitgevoerd, en de kosten op de eigenaar kan verhalen.

## Zorgplicht
De in de tekst genoemde **zorgplicht** houdt in dat de toestand van een gebouw geen gevaar voor gezondheid of veiligheid mag laten ontstaan of voortbestaan. Het boek verwijst naar artikel 1a van de Woningwet. Het noemt daarnaast het rustige woongenot dat een verhuurder moet bieden.

De Woningwet raakt de toestand, het gebruik en het slopen van gebouwen en welstand. Veel regels zijn later verplaatst naar andere wetten of besluiten. Lees oude regels dus niet alsof de hele oude werkwijze nog onveranderd geldt.

De tekst noemt als historische stappen de Wro (1965) en de Wabo (2010). De Wabo werd op 1 januari 2024 vervangen door de Omgevingswet. De datum 1 januari 2022 die het boek bij een herziening noemt, is een vermelding uit die bron, geen verklaring dat dit vandaag de laatste wijziging is.

**Bron:** aangeleverde LOI-foto’s, p. 2.20, p. 2.21.


# 09 • Vergunning, melding, welstand en monumenten

# Drie routes die je niet moet verwarren
**Vergunningplichtig:** je hebt toestemming van de overheid nodig voor de betreffende activiteit. **Meldingsplichtig:** je moet de activiteit melden en aan de bijbehorende regels voldoen. **Vergunningvrij:** voor die activiteit is geen vergunning nodig, maar andere regels blijven gelden.

Of iets in een route valt, hangt onder andere af van de plaats, grootte, hoogte, oppervlakte, afstand tot grenzen en de ligging aan de voor- of achterkant. Ook het omgevingsplan en eventuele bescherming als monument tellen mee. Trek daarom niet uit één voorbeeld de conclusie dat ieder vergelijkbaar werk vergunningvrij is.

## Voorbeelden uit het boek
Nieuwe hoofdgebouwen en grotere verbouwingen kunnen een vergunning nodig hebben. Een verandering van gebruik die niet in het omgevingsplan past, kan ook toestemming vragen. Soms spelen daarnaast regels voor brandveilig gebruik of milieu.

Bij kleine achteraanbouwen, bijgebouwen, dakkapellen achter, dakramen, schuttingen en overkappingen kunnen vrijstellingen gelden. Alleen als aan de voorwaarden wordt voldaan. Gewoon onderhoud of een interne aanpassing zonder verandering van constructie of gebruik kan vaak vergunningvrij zijn. Ook dat moet je per situatie controleren.

Een melding is geen volledige vergunningprocedure. De bron noemt meldingen bij bepaalde gebruikssituaties en tijdelijke bouwwerken. Dit is geen complete lijst van alle meldplichten.

## Vergunningvrij is niet regelvrij
Ook vergunningvrij werk moet voldoen aan toepasselijke technische regels uit het **Bbl**. De overheid kan achteraf optreden. Regels tussen buren, uit het privaatrecht, kunnen daarnaast gelden. Controleer vooraf het **Omgevingsloket** en het gemeentelijke **omgevingsplan**.

## Welstand en bescherming
**Welstand** gaat over het uiterlijk en de plaatsing van een bouwwerk in relatie tot de omgeving. Een **welstandsnota** bevat gemeentelijke criteria. De gemeenteraad stelt die vast. B&W passen de criteria toe, met advies van bijvoorbeeld een onafhankelijke welstandscommissie of stadsbouwmeester. Gebieden kunnen in de beschreven regeling welstandsvrij zijn.

Voor beschermde monumenten en beschermde stads- of dorpsgezichten gelden bijzondere regels. De tekst bespreekt ook historische Wabo-vergunningen voor bouwen, monumenten veranderen en bepaalde sloopactiviteiten. De **Wabo** bundelde vanaf 2010 ongeveer 25 toestemmingen. Zij is sinds 1 januari 2024 vervangen door de Omgevingswet. De samenhang van vergunningverlening, toezicht, handhaving en bezwaar/beroep blijft een belangrijk leerpunt.

**Bron:** aangeleverde LOI-foto’s, p. 2.21, p. 2.22, p. 2.23, p. 2.24.


# 10 • Van Wro en bestemmingsplan naar Omgevingswet

# De oude ruimtelijke ordening
De **Wro**, Wet ruimtelijke ordening, regelde hoe grond en ruimte werden gebruikt. Een gemeentelijk **bestemmingsplan** gaf aan wat waar mocht: wonen, werken of recreëren, en bijvoorbeeld welke bouwhoogte en omvang toegestaan waren. Het plan bond overheid, bedrijven en burgers.

Afwijken kon niet zomaar. De tekst noemt een vergunning en een goede ruimtelijke onderbouwing. Rijk, provincie en gemeente maakten **structuurvisies**: plannen op hoofdlijnen voor de ruimtelijke ontwikkeling. Het Rijk keek bijvoorbeeld naar grote infrastructuur, waterveiligheid en natuur. Provincies naar landschap en groen. Gemeenten naar lokale woningbouw, bedrijventerreinen en parken.

## De Omgevingswet
Sinds **1 januari 2024** is de Wro vervangen door de **Omgevingswet**. Deze brengt volgens het boek 26 wetten over de fysieke leefomgeving samen. De **fysieke leefomgeving** is de omgeving waarin je woont en leeft: onder andere ruimte, water, natuur, milieu, gebouwen en erfgoed.

Het boek noemt onder andere de vroegere Wabo, Wro, Wet natuurbescherming, Waterwet en Tracéwet. De onderwerpen zijn samengebracht om regels duidelijker te maken, belangen samen te beoordelen, maatwerk mogelijk te maken en besluitvorming te verbeteren. **Participatie** betekent dat betrokkenen kunnen meedenken en hun belangen inbrengen.

## Omgevingsplan
Het gemeentelijke **omgevingsplan** is breder dan het oude bestemmingsplan. Het gaat niet alleen om functies van grond en bouwen, maar ook om bijvoorbeeld milieu, water, natuur en erfgoed. Bestaande regels gaan in de overgang mee. Het boek noemt 2029 als overgangstermijn; die datum is hier niet geactualiseerd of als toetsfeit gebruikt.

Er blijven vergunningen en voorwaarden. Afwijken vraagt een motivering. De tekst noemt mogelijkheden voor maatwerk en tijdelijke of experimentele oplossingen. Dat betekent niet dat alles mag. Samen vormen Omgevingswet, omgevingsplan en Bbl belangrijke onderdelen van het kader voor bouwen.

**Bron:** aangeleverde LOI-foto’s, p. 2.24, p. 2.25, p. 2.26.


# 11 • Wat regelt het Bbl?

# Eén technisch kader voor gebouwen
Vroeger verschilden gemeentelijke bouwverordeningen sterk. Het **Bouwbesluit** uit 1992 bracht landelijke technische regels. Het was een **AMvB**, algemene maatregel van bestuur: een besluit van de regering met nadere regels op basis van een wet. In 2012 kwam een herziening. Op 1 januari 2024 werd het Bouwbesluit vervangen door het **Bbl: Besluit bouwwerken leefomgeving**.

Het boek ordent de regels in zeven groepen:

## 1. Veiligheid
Een gebouw moet bijvoorbeeld stevig genoeg zijn en brandveilig zijn. Ook veilig gebruik speelt mee, zoals trappen en kunnen vluchten bij gevaar.

## 2. Gezondheid
Denk aan geluid, vocht, afvoer van vuil- en regenwater, ventilatie, luchttoevoer en afvoer bij verbranding, schadelijke stoffen, ongedierte, water en daglicht.

## 3. Bruikbaarheid
Een gebouw moet voor zijn functie bruikbaar zijn. Denk aan bereikbaarheid, afmetingen, benodigde ruimten en plaats voor voorzieningen.

## 4. Energie en milieu
Beperk warmteverlies, ongewenste luchtlekken en milieubelasting van materialen. Duurzaam bouwen speelt hierin mee.

## 5. Installaties
Dit gaat over voorzieningen zoals riolering, elektriciteit, gas en drinkwater.

## 6. Gebruik
Het veilig en gezond gebruiken van gebouwen en terreinen, bijvoorbeeld het vrijhouden van vluchtroutes.

## 7. Bouwen en slopen
Tijdens werkzaamheden moet hinder en gevaar voor de omgeving worden beperkt.

## Niet elk gebouw krijgt dezelfde eisen
Het Bbl onderscheidt volgens de bron twaalf hoofdgebruiksfuncties. Voorbeelden: wonen, kantoor, winkel, onderwijs, bijeenkomst en een bouwwerk dat geen gebouw is. De functie bepaalt mede welke regels gelden. Ook maakt het uit of het om bestaande bouw of nieuwbouw gaat. Voor bestaande bouw zijn eisen doorgaans minder streng dan voor nieuwbouw.

**Bron:** aangeleverde LOI-foto’s, p. 2.26, p. 2.27.


# 12 • Gebruiksfunctie, gebied en ruimte

# Eerst de functie: waarvoor wordt dit gebruikt?
Een **gebruiksfunctie** is een deel van één of meer bouwwerken met hetzelfde gebruik, dat samen één eenheid vormt en op hetzelfde perceel ligt. Het boek noemt twaalf hoofdgebruiksfuncties met verdere onderverdelingen.

Eén gebouw kan meerdere gebruiksfuncties hebben. In een kantoorgebouw kunnen bijvoorbeeld kantoorruimten én een vergader- of kantinegedeelte met een bijeenkomstfunctie zitten. Bij een aanvraag geef je het bedoelde gebruik aan.

## Daarna het gebied
Een **gebruiksgebied** is een vrij indeelbaar deel van een gebruiksfunctie op één bouwlaag, bedoeld voor de activiteiten van die functie. In de algemene omschrijving horen toiletten, badruimten, technische ruimten en verkeersruimten daar niet bij.

Er zijn twee belangrijke soorten:
- **Verblijfsgebied:** het verblijf van mensen staat centraal.
- **Functiegebied:** het verblijf van mensen is niet het hoofddoel, of is ondergeschikt aan de activiteit.

Het gaat om het bedoelde gebruik. Een plek waar mensen werken aan goederen, diensten leveren of sporten kan juist eisen voor het verblijf van mensen nodig hebben. Trek dus niet de conclusie dat iedere werkplek automatisch een functiegebied is.

## En dan de afzonderlijke ruimte
Een **verblijfsruimte** is een ruimte binnen een verblijfsgebied waar mensen verblijven. Een **functieruimte** is een ruimte binnen een functiegebied. Een gebied kan dus in afzonderlijke ruimten worden verdeeld.

Het boek noemt een sanitairgebouw op een camping als bijzonder voorbeeld van functieruimten. Dat moet je in de context van die gebruiksfunctie lezen; het maakt niet ieder toilet in elke woning onderdeel van het gebruiksgebied.

**Bedgebied** en **bedruimte** zijn bijzondere vormen van verblijfsgebied en verblijfsruimte, bedoeld voor bedden. Er kunnen strengere eisen gelden, bijvoorbeeld voor geluid bij luchthavens. Een bedruimte ligt altijd in een bedgebied.

## Waarom deze woorden belangrijk zijn
Regels kunnen gelden voor het hele gebied of voor één ruimte. Je mag de indeling niet zo kiezen dat onveilige of ongezonde ruimten ontstaan. Daarvoor zijn ondergrenzen, de **vangneteisen**. De bron noemt bij verblijfsgebied minimaal 5 m²; bij concrete toepassingen moet je de overige voorwaarden mee lezen.

**Bron:** aangeleverde LOI-foto’s, p. 2.27, p. 2.28, p. 2.29.


# 13 • Oppervlakte, techniek en toegankelijkheid

# Niet ieder oppervlak tel je op dezelfde manier
Het **gebruiksoppervlak**, ook gebruiksoppervlakte genoemd, wordt bepaald volgens **NEN 2580**. De bron beschrijft het vloeroppervlak binnen de omhullende wanden, met aftrekposten. Voorbeelden zijn dragende delen en delen met minder dan 1,5 meter vrije hoogte. Ook maakt de tekst onderscheid met buiten de woning gelegen bergingen, ketel- en trappenruimten.

Dit is geen volledige meetinstructie. Gebruik niet alleen deze korte uitleg om zelf een officiële meting te doen. De passage over rechten van kopers bij afwijkende maten staat als aandachtspunt bij Start hier. De betekenis van het begrip en de verwijzing naar de norm kun je wel leren.

## Ruimten met een andere taak
Een **technische ruimte** is bedoeld voor apparatuur die nodig is om het gebouw te laten functioneren. Denk aan een meterruimte, liftmachineruimte of ruimte voor verwarming en luchtbehandeling.

Een woonkamer wordt niet automatisch een technische ruimte omdat er een lamp of brandmelder hangt. Het gaat om de bestemming van de ruimte, niet om elk apparaat dat erin aanwezig is.

Een **verkeersruimte** is bedoeld om andere ruimten te bereiken. Denk als eenvoudig voorbeeld aan een gang. In de omschrijving is het geen verblijfsgebied, functiegebied, toilet, badruimte of technische ruimte.

## Zelfstandig kunnen gebruiken
Een **toegankelijkheidssector** is een gedeelte van het gebouw dat een rolstoelgebruiker zelfstandig kan bereiken en gebruiken. Daarvoor zijn voldoende ruimte om te draaien, overbrugbare hoogteverschillen en bruikbare bediening en inrichting nodig.

Een **integraal toegankelijke toilet- of badruimte** kan ook worden gebruikt door iemand met een rolstoel of een verminderde mobiliteit. Of zo’n ruimte verplicht is, hangt af van onder andere gebruik en omvang. Zij ligt volgens de bron altijd binnen de toegankelijkheidssector.

**Bron:** aangeleverde LOI-foto’s, p. 2.29, p. 2.30.


# 14 • Woonfunctie, maten en prestatie-eisen

# Een woonfunctie is bedoeld om te wonen
De tekst noemt onder andere een vrijstaande woning, flatwoning, portiekwoning, studentenhuisvesting, woonwagen en drijvende woning. Lees de aparte bronnotitie over woonschip en woonark bij Start hier.

De indeling van een woning is niet helemaal voorgeschreven. Er zijn wel ondergrenzen en voorzieningen nodig. De maten hieronder zijn de lesstof zoals aangeleverd, geen compleet overzicht voor ieder bestaand of nieuw gebouw.

## Maten uit het boek
- Pagina 2.28 noemt voor een verblijfsruimte: minimaal **5 m²** vloeroppervlak, **1,8 meter** breedte en **2,60 meter** hoogte.
- Bij de woonfunctie noemt pagina 2.30 minimaal **18 m² niet-gemeenschappelijk verblijfsgebied**.
- Daarnaast noemt die pagina dat minimaal **55% van het gebruiksoppervlak** verblijfsgebied is, en een minimum van **11 m²**, **3 meter breedte** en **2,60 meter hoogte** in de opsomming van de bruikbaarheidseisen. Lees deze punten met de precieze toepassingscontext van de normtekst; ze betekenen niet dat iedere kamer 11 m² moet zijn.
- Er zijn eisen aan een toilet en badruimte en opstelplaatsen voor een kooktoestel, aanrecht, verwarming en warmwatervoorziening. De foto's geven hier niet alle bijbehorende maten; die zijn niet aangevuld.

## Wat is een prestatie-eis?
Een **prestatie-eis** vertelt hoe goed iets minimaal moet presteren. Er is een concrete grenswaarde én een manier om vast te stellen of je daaraan voldoet. Een getal zonder meet- of rekenmethode is dus niet de hele eis.

Normen geven methoden voor meten, rekenen en testen. Een erkende kwaliteitsverklaring kan volgens de bron als bewijs dienen dat een materiaal of onderdeel aan de bedoelde eisen voldoet.

**NPR** betekent Nederlandse praktijkrichtlijn. **NTR** betekent Nederlandse technische richtlijn. Ze geven praktische uitwerkingen of voorbeelden om aan prestatie-eisen te voldoen. Ze kunnen voorkomen dat je voor elke bekende oplossing helemaal opnieuw moet rekenen of meten.

**Bron:** aangeleverde LOI-foto’s, p. 2.30, p. 2.31.


# 15 • Wkb, kwaliteitsborger en bruidsschat

# Wie controleert welk deel?
De bron noemt een **knip**: een scheiding tussen beoordeling door de overheid en technische kwaliteitscontrole. De gemeente houdt taken rond het omgevingsplan, de ruimtelijke beoordeling, welstand en handhaving. Voor bouwactiviteiten waarop het stelsel van kwaliteitsborging van toepassing is, controleert een onafhankelijke kwaliteitsborger de bouwtechnische kwaliteit. Dit betekent niet dat de gemeente helemaal verdwijnt.

**Kwaliteitsborging** is het geheel van controles, maatregelen en vastlegging waarmee je aannemelijk maakt dat aan de regels wordt voldaan. De **kwaliteitsborger** werkt onafhankelijk met een toegelaten instrument. Een **borgingsplan** legt vast welke risico’s er zijn en hoe de controle plaatsvindt. Het gaat om ontwerp én uitvoering. Lees de bronnotitie over KOMO/BRL bij Start hier.

## Gevolg is niet hetzelfde als kans
Een **gevolgklasse** gaat over de ernst van de gevolgen als iets misgaat. De tekst zet dit naast een **risicoklasse**, waar de kans op problemen een rol speelt. Ingewikkeldere gebouwen kunnen zwaardere gevolgen hebben. Eenvoudige woningen en eenvoudige bedrijfsgebouwen noemt het boek als voorbeelden bij de lage gevolgklasse, zoals gevolgklasse 1. Niet ieder gebouw valt zonder verdere voorwaarden in zo’n voorbeeld.

## Wkb
De **Wet kwaliteitsborging voor het bouwen (Wkb)** ging volgens de tekst op **1 januari 2024** gefaseerd in. Het doel is betere bouwkwaliteit, controle en een sterkere positie van de opdrachtgever. Het stelsel start bij eenvoudige, laagrisicobouwwerken. Verdere uitbreiding hangt af van overheidsbesluiten. De aansprakelijkheidsregels hebben volgens het boek een bredere werking dan alleen die eerste groep.

De tekst noemt: onafhankelijke controles; aansprakelijkheid van de aannemer voor door hem veroorzaakte gebreken, ook als die later blijken; informatie over verzekering tegen onder andere faillissement of schade; en de 5%-regeling bij de notaris. Die laatste is hier alleen als hoofdlijn opgenomen: de precieze voorwaarden en termijnen staan niet volledig op deze pagina. Bij problemen kan de gemeente ingrijpen en het werk stilleggen.

## Bruidsschat
De **bruidsschat** is de naam voor regels die bij de overgang naar de Omgevingswet van het Rijk naar gemeenten en hun omgevingsplan overgaan. De tekst bespreekt dit samen met het tijdelijke omgevingsplan en bestaande regels. Zo ontstaat niet ineens een gat zonder regels. De gemeente kan binnen het nieuwe stelsel regels vervangen of aanvullen.

**Bron:** aangeleverde LOI-foto’s, p. 2.31, p. 2.32.


# 16 • Arbeid, bodem, bomen, leges en water

# Meer regels dan alleen het Bbl
Bij een bouwproject kunnen verschillende regelingen tegelijk spelen. De regels hebben elk een eigen doel.

## Veilig en gezond werken
Het **Arbobesluit Bouwproces** gaat over arbeidsomstandigheden. Veiligheid en gezondheid van werkenden moeten worden meegenomen vanaf initiatief en ontwerp, tijdens de bouw en ook bij beheer en onderhoud. Opdrachtgever, ontwerper en uitvoerende partijen hebben daarbij ieder hun rol.

## Bodem beschermen
Het **Besluit bodemkwaliteit (Bbk)** gaat in deze tekst over het toepassen van bouwstoffen, grond en baggerspecie op of in de bodem of in oppervlaktewater. Het doel is onder andere vervuiling voorkomen. Dat kan ook spelen bij een oprit of het ophogen van een tuin.

## Bomen kappen
Een gemeente kan een **kapverordening** hebben. Dan kan voor het kappen van een boom een vergunning nodig zijn. Niet elke gemeente heeft dezelfde regeling. Een herplantplicht kan onderdeel zijn: je moet dan een nieuwe boom planten, bijvoorbeeld op je eigen terrein.

## Kosten van een aanvraag
**Leges** zijn bedragen die de overheid rekent voor bepaalde diensten, zoals het behandelen van een vergunningaanvraag. Gemeentelijke tarieven staan in een **legesverordening** en kunnen verschillen. De tekst noemt ook eventuele kosten voor voorgeschreven publicaties.

## Water en dijken
Een **waterschap** heeft taken rond het watersysteem en waterkeringen. Voor bouwen in of op een dijk, in een uiterwaard of voor leidingen in een dijk kan toestemming van het waterschap nodig zijn. Een gemeentelijke procedure neemt niet automatisch alle andere toestemmingen weg. De bron vermeldt dat het ontbreken van de bedoelde waterschapstoestemming op zichzelf geen reden is om de omgevingsvergunning te weigeren; dat betekent niet dat je zonder die benodigde toestemming mag beginnen.

De kern: controleer per activiteit welke regels en bevoegde instanties erbij horen. Eén woord als bouwvergunning dekt niet vanzelf het hele project.

**Bron:** aangeleverde LOI-foto’s, p. 2.33.


## Plattegronden bij de opdrachten
Voeg de drie meegeleverde afbeeldingen toe als voorbeelden bij dit deelonderwerp. Gebruik de titels Plattegrond A, Plattegrond B en Plattegrond C. De eerste drie vragen over woningindelingen verwijzen naar deze voorbeelden. Bron: uitsneden uit afbeelding 7, LOI-pagina 2.8.
