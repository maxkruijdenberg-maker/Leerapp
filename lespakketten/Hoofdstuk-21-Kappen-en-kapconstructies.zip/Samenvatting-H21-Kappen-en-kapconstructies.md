# Hoofdstuk 21 – Kappen en kapconstructies

## Dakvorm en krachten

Een **kapconstructie** draagt de dakbedekking, het eigen gewicht en belastingen zoals sneeuw en wind. De krachten gaan via balken, spanten of dakelementen naar dragende wanden en liggers. Opwaartse wind kan aan het dak trekken. **Verankering** verbindt de kap met het gebouw. **Windverbanden** of een daarvoor ontworpen dakbeschot helpen voorkomen dat de kap scheef vervormt.

Een **lessenaarsdak** heeft één hellend dakvlak. Een **zadeldak** heeft twee dakvlakken die bij de **nok** samenkomen. Een **schilddak** heeft ook hellende dakvlakken aan de kopse kanten. Bij een **mansardedak** is het onderste deel van het dakvlak steiler dan het bovenste. Een **hoekkeper** ligt op een uitwendige hoek tussen dakvlakken. Een **kilkeper** ligt in een inwendige hoek. Beide moeten in de constructie passend ondersteund worden.

## Sporen, gordingen en spanten

**Sporen** lopen in de richting van de dakhelling, van de dakvoet naar de nok. Bij een **sporenkap** dragen dicht bij elkaar geplaatste sporen het dakvlak. Een **gording** loopt evenwijdig aan de nok. Bij een **gordingenkap** dragen de gordingen het dakbeschot, direct of via sporen. De gordingen steunen op dragende muren of op **spanten**. Een **muurplaat** is een balk aan de dakvoet die de krachten uit de kap naar de muur overbrengt. De verbinding met de muur moet bij de optredende krachten passen.

Een **spant** is een dragend raamwerk dat meestal dwars op de nok staat. Schuine **spantbenen** kunnen naar buiten drukken. Die **spatkrachten** moeten worden opgevangen, bijvoorbeeld met een **trekbalk** die de voeten van de spantbenen bij elkaar houdt. Een **vakwerkspant** verdeelt de krachten via staven die driehoeken vormen. **Gelamineerde houten spanten** bestaan uit verlijmde houtlagen en kunnen ook gebogen worden gemaakt.

## Isolatie en prefab dakelementen

Bij een **warm dak** ligt de isolatie aan de buitenzijde van het dakbeschot, waardoor het beschot relatief warm blijft. Een **koud dak** heeft isolatie onder het dakbeschot. Het beschot blijft dan koud en vocht kan er condenseren. Bij een onverwarmde zolder kan de isolatie ook in de zoldervloer liggen. Dan ligt de zolder buiten de verwarmde ruimte. De hele dakopbouw bepaalt hoe vocht wordt beheerst. Een doorlopende **lucht- en dampremmende laag** aan de warme kant kan, waar de opbouw die vraagt, de aanvoer van vochtige binnenlucht beperken. Laat naden en aansluitingen bij doorvoeren, gevel en nok zorgvuldig sluiten. Bij een woningscheidende wand moet de dakaansluiting ook de overdracht van geluid en brand beperken.

**Prefab dakplaten** worden vooraf gemaakt en kunnen draagdelen, beschot en isolatie combineren. Een **sandwichpaneel** heeft isolatie tussen twee platen. Bij een **scharnierkap** zijn twee prefab dakhelften bij de nok met scharnieren verbonden. Ze worden op de bouwplaats uitgeklapt, geplaatst en verankerd. Ondersteuning en stabiliteit moeten passen bij het ontwerp van de kap.

## Dakopeningen en goten

Bij een **dakdoorbreking**, zoals een schoorsteen of dakkapel, kan een dragend deel onderbroken worden. Een **raveling** met hulpbalken brengt de belasting rond de opening over op doorgaande delen. Wordt de nok onderbroken, dan kan extra ondersteuning nodig zijn. Bij een **dakkapel** moeten isolatie, luchtdichting en waterkering doorlopen bij de zijwanden, dakvoet en aansluiting met het bestaande dak.

Een **dakgoot** vangt water bij de dakvoet op en voert het af naar de **hemelwaterafvoer**. Een **kilgoot** voert het water af waar twee dakvlakken in een binnenhoek samenkomen. Een **zalinggoot** leidt water achter een brede dakdoorbreking langs naar de zijkanten. Goot en afvoer moeten voldoende water kunnen verwerken. Bij een metalen goot moeten de aansluitingen ook uitzetting en krimp kunnen opnemen.
