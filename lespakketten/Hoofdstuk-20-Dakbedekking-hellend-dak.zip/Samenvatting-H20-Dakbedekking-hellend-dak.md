# Hoofdstuk 20 – Dakbedekking hellend dak

## Hoe een pannendak werkt

Een **pannendak** voert regen af doordat de dakpannen elkaar overlappen. Water loopt van de bovenste pan op de pan eronder, richting **dakvoet**, de onderste rand van het dakvlak. Daar komt het water in de goot. De onderste rij moet zo aansluiten dat regen in de goot valt en water dat onder de pannen terechtkomt veilig naar buiten kan. Een geschikt **onderdak** beschermt de constructie tegen binnengedrongen regen of stuifsneeuw. De benodigde dakhelling en overlap hangen af van het panmodel, de ligging en de opbouw van het dak.

**Tengels** lopen in de richting van de dakhelling, van goot naar nok. Ze houden de **panlatten** vrij van het onderdak. De panlatten lopen dwars op de helling en dragen de pannen. De pan hangt met een **ophangnok**, ook **neus** genoemd, achter de panlat. De **panlatafstand** is de afstand tussen opeenvolgende panlatten. Die bepaalt mede hoeveel twee rijen elkaar overlappen. De **werkende maat** is de maat die één pan na overlap op het dakvlak inneemt. Stem de latverdeling en het aantal pannen af op de werkende maten van het gekozen model en op de details bij nok, goot en gevelrand.

## Panvorm, materiaal en afwerking

De **kopsluiting** is de aansluiting tussen twee pannen boven elkaar. De **zijsluiting** verbindt pannen naast elkaar. Het overlappende deel aan de zijkant heet de **wel**. Gevormde sluitingen helpen regen en wind buiten te houden. Een **oude holle pan** heeft een doorlopend golvend profiel zonder gevormde kop- en zijsluitingen. Moderne holle en vlakke pannen kunnen zulke sluitingen wel hebben. Het profiel van de pan bepaalt hoe water naar beneden wordt afgevoerd.

**Keramische dakpannen** worden gemaakt van gebakken klei. De kleur hangt onder meer af van de klei, het bakproces en de afwerking. Een **engobe** is een dunne deklaag op basis van klei die wordt meegebakken. **Glazuur** vormt bij het bakken een glasachtige oppervlaktelaag. Bij **smoren** ontstaat door zuurstofarm bakken een donkere kleur. **Betondakpannen** worden gevormd uit een mengsel van cement, zand en water. Ze kunnen een gekleurde oppervlaktelaag hebben. Keramische en betonnen pannen zijn er in verschillende modellen. Controleer bij renovatie of profiel, maat en hulpstukken werkelijk op elkaar aansluiten.

## Ventilatie, bevestiging en hulpstukken

**Ventilatie onder de pannen** helpt vocht af te voeren en onderdelen te laten drogen. Lucht kan bij de dakvoet binnenkomen en hogerop ontsnappen, bijvoorbeeld via een **ventilatiepan** of een ventilerende nok. Houd de lucht- en waterwegen open. Bij de dakvoet kan een **vogelwering** de openingen tegen vogels beschermen terwijl lucht kan blijven passeren. **Panverankering** houdt de bedekking op haar plaats bij windzuiging. Daarvoor worden bijvoorbeeld **panhaken** gebruikt. Welke en hoeveel bevestigingen nodig zijn, hangt af van het daksysteem en de windbelasting. Bij dakranden, hoeken en de nok kan de windbelasting hoger zijn.

**Hulpstukken** werken de randen, hoeken en openingen van het pannendak af. Een **nokvorst** dekt de bovenste aansluiting tussen dakvlakken af. Een **hoekkepervorst** dekt een uitwendige schuine dakhoek af. Een **gevelpan** sluit de zijkant van het dak af. Een **doorvoerpan** zorgt voor een passende aansluiting rond een leiding door het dak. Bij een **droge nok** worden de vorsten mechanisch bevestigd en sluit een passend nokdetail de aansluiting af. Een ventilerende uitvoering laat ook lucht door. Hulpstukken en bevestigingen moeten passen bij het panmodel en de dakopbouw.
