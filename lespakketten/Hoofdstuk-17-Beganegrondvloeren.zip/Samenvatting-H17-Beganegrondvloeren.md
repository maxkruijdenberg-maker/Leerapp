# Hoofdstuk 17 – Beganegrondvloeren

## Draagwijze, vocht en warmte

De **beganegrondvloer** draagt het eigen gewicht en de belasting door gebruik. Een **vloer op grondslag** rust op een geschikte, verdichte ondergrond. Ongelijke zetting kan scheuren veroorzaken. Een **vrijdragende vloer** draagt de belasting af naar opleggingen, zoals bouwmuren of funderingsbalken. De bodem eronder ondersteunt de vloer niet. Onder zo’n vloer kan een **kruipruimte** liggen, die toegang geeft tot de onderkant van de vloer en tot leidingen.

Een vloer boven een kruipruimte moet warmteverlies en ongewenste luchtstroming beperken. **Vloerisolatie** remt warmtestroom door de vloer. Een onderbreking bij de oplegging of gevelrand kan een **koudebrug** vormen. Dicht naden, leidingdoorvoeren en het **kruipluik** af waar kruipruimtelucht anders de woning in kan stromen. Een **bodemafsluiting** op de grond in de kruipruimte beperkt verdamping vanuit de bodem. Dat is een andere functie dan die van vloerisolatie. **Kruipruimteventilatie** kan helpen vocht af te voeren. Beoordeel ook waar vocht vandaan komt en of afvoer mogelijk is. Bij een houten vloer kan langdurig vocht leiden tot schimmel en houtrot.

## Betonnen vloersystemen

Een **in het werk gestorte betonvloer** krijgt zijn vorm op de bouwplaats. Bij een vrijdragende uitvoering houdt de **bekisting** de verse specie op haar plaats totdat het beton voldoende sterk is. Een **verloren bekisting** blijft zitten. **Prefab vloerelementen** worden vooraf gemaakt en op de bouwplaats gemonteerd. Leg ze volgens het legplan. Oplegging en sparingen horen bij het constructief ontwerp.

Bij een **breedplaatvloer** vormt een dunne prefab betonplaat de blijvende bekisting en bevat die plaat een deel van de wapening. De ter plaatse gestorte betonlaag werkt na verharding samen met de plaat. Tijdens de bouw kan tijdelijke ondersteuning nodig zijn. Een **combinatievloer**, ook **broodjesvloer**, heeft dragende balkjes met vulelementen ertussen. Schuimvulling kan tegelijk isoleren en als bekisting dienen. De vulelementen dragen de gebruiksbelasting niet. Een **druklaag** is een constructieve betonlaag die belasting kan spreiden en onderdelen kan laten samenwerken als de vloer daarvoor is ontworpen.

Een **kanaalplaatvloer** bestaat uit prefab platen met holle kanalen in de lengterichting die het gewicht verlagen. Een **raveelconstructie** voert rond een grotere opening de belasting van onderbroken vloerdelen af naar geschikte opleggingen. Bij **ribbenvloeren** dragen ribben onder de plaat bij aan de draagwerking. In bepaalde series oude **Kwaaitaal- en Mantavloeren** kan chlorideaantasting tot roestende wapening en afspringend beton leiden. Laat bij verdenking de staat van de vloer beoordelen. De productnaam alleen zegt niet hoeveel schade er is.

## Houten vloeren en afwerking

Een **houten balklaag** draagt de vloerdelen of vloerplaten. Een **onderslagbalk** of **onderslagmuurtje** kan de balken tussentijds ondersteunen en zo hun vrije overspanning verkleinen. Een **poer** is een plaatselijke steun die belasting aan de ondergrond of fundering doorgeeft. Let bij verbetering van een bestaande vloer op vocht bij de **balkkoppen**, de uiteinden van de balken bij hun oplegging. Isolatie tussen of onder de balken helpt tegen warmteverlies. De vloeropbouw moet het hout voldoende laten drogen.

De **constructievloer** draagt. Een **dekvloer** ligt daar bovenop en vormt een vlakke basis voor bijvoorbeeld tegels, parket of een andere vloerbedekking. Bij een **zwevende dekvloer** scheidt een veerkrachtige laag de dekvloer van de draagvloer en houdt randisolatie de dekvloer vrij van de wanden. Zo wordt minder **contactgeluid**, zoals het geluid van voetstappen, aan het gebouw doorgegeven. Een harde verbinding langs de rand kan dit effect verminderen. Een zware of stijve afwerking op een bestaande houten balklaag vraagt controle van de belasting en doorbuiging.
