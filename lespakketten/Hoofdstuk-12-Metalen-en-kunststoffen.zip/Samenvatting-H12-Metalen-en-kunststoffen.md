# Hoofdstuk 12 – Metalen en kunststoffen

## Staal in de bouw

Bij **ferrometalen** is ijzer het hoofdbestanddeel. **Staal** is een legering van vooral ijzer met een kleine hoeveelheid koolstof. Bij de productie uit erts ontstaat eerst koolstofrijk ruwijzer. Door het koolstofgehalte te verlagen en de samenstelling te sturen, krijgt staal de eigenschappen die voor de toepassing nodig zijn. **Plaatstaal** wordt onder meer gebruikt voor gevelplaten. **Profielstaal**, zoals I- en H-profielen en kokers, wordt veel gebruikt voor liggers en kolommen. Stalen onderdelen worden bijvoorbeeld met **bouten** verbonden of **gelast**.

Metaal geleidt warmte goed. Een metalen onderdeel dat door de isolatielaag heen loopt, kan daardoor een **koudebrug** vormen: een plek waar extra warmte door de constructie stroomt. Staal is onbrandbaar, maar verliest bij hoge temperatuur sterkte en stijfheid. **Brandwerende bekleding** of een geschikte coating vertraagt het opwarmen van een stalen draagconstructie.

## Corrosie en andere metalen

**Corrosie** is aantasting van metaal door reacties met de omgeving. Een **coating** houdt vocht en zuurstof zo veel mogelijk weg van het staal. Bij **verzinken** krijgt staal een laag zink. Zink vormt een barrière en kan bij een kleine beschadiging als **offerlaag** het staal beschermen doordat het zelf eerder corrodeert. Bij **galvanische corrosie** zijn verschillende metalen elektrisch met elkaar verbonden en is er een geleidende vloeistof, zoals regenwater. Het minder edele metaal wordt dan sneller aangetast. Een isolerende scheiding kan het elektrisch contact verbreken.

**Roestvast staal (rvs)** wordt beschermd door een dunne chroomrijke oxidelaag. **Weervast staal**, zoals cortenstaal, vormt onder geschikte omstandigheden een roestlaag die verdere aantasting vertraagt. Bij **non-ferrometalen** is ijzer niet het hoofdbestanddeel. **Aluminium** is licht en vormt een beschermende oxidelaag. **Anodiseren** maakt die laag kunstmatig dikker. **Koper** kan buiten een beschermend **patina** vormen. **Zink** wordt ook gebruikt voor goten en dakbekleding. **Bladlood** is goed vervormbaar en kan als waterkering dienen. Beperk blootstelling aan lood en kies waar passend een alternatief. Een **legering** combineert een metaal met andere elementen. **Messing** is voornamelijk koper met zink, **brons** meestal koper met tin.

Bij verwarming zet metaal uit. De **lineaire uitzettingscoëfficiënt** geeft de lengteverandering per meter en per graad aan. Reken met lengteverandering = coëfficiënt × oorspronkelijke lengte × temperatuurverschil. Gebruik passende eenheden en geef lange delen ruimte om te bewegen.

## Kunststoffen en toepassingen

**Kunststoffen** bestaan uit polymeren, grote moleculen die uit herhaalde bouwstenen bestaan. **Thermoplasten** worden zacht bij verwarming en weer hard bij afkoeling. Ze kunnen binnen geschikte temperatuurgrenzen opnieuw worden gevormd. Uitgeharde **thermoharders** hebben een vast netwerk. Ze smelten daarbij niet opnieuw en ontleden bij sterke verhitting. **Elastomeren** zoals EPDM zijn rubberachtig en veren terug. EPDM wordt onder meer gebruikt als dakbaan en afdichting.

Hard **pvc** wordt onder meer gebruikt voor afvoerbuizen en kozijnprofielen. **Weekmakers** kunnen pvc soepeler maken. **PE** en **PP** worden ook toegepast in leidingen en hulpstukken, afhankelijk van de toepassing. **PMMA** en **polycarbonaat (PC)** kunnen transparant zijn. PC is doorgaans slagvaster. **EPS** is isolatieschuim van geëxpandeerde polystyreenkorrels, **XPS** is geëxtrudeerd polystyreenschuim. **PUR** en **PIR** worden eveneens als isolatieschuim toegepast. **Glasvezelversterkt polyester** combineert kunststof met vezels voor meer sterkte en stijfheid. Bij **kruip** vervormt een kunststof geleidelijk onder langdurige belasting. Schone, gescheiden afvalstromen maken materiaalrecycling beter mogelijk.

## Kit en bewegende voegen

**Afdichtingskit** sluit een voeg af tegen bijvoorbeeld water of tocht. **Elastische kit** veert na vervorming grotendeels terug. **Plastische kit** houdt de vervorming grotendeels vast. **Plasto-elastische kit** herstelt maar gedeeltelijk. Kies voor een bewegende voeg een product dat de verwachte beweging kan opnemen en goed hecht op de ondergrond. Een **primer** kan de hechting verbeteren. **Rugvulling** helpt de kitdiepte te regelen en voorkomt bij geschikte uitvoering dat de kit ook aan de voegbodem hecht. Volg de productgegevens voor voegmaten en verwerking.
