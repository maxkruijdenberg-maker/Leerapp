# Hoofdstuk 18 – Verdiepingsvloeren en trappen

## Draagconstructie van verdiepingsvloeren

Een **verdiepingsvloer** draagt zijn eigen gewicht en de belasting door gebruik af naar wanden of liggers. **Oplegging** brengt de belasting over op die steunpunten. **Verankering** verbindt de vloer met de rest van het gebouw. Als de vloer daarvoor is ontworpen, kan hij als **horizontale schijf** krachten zoals windbelasting naar de stabiliteitswanden voeren. Voor een bruikbare vloer tellen ook doorbuiging, trillingen, geluidisolatie en brandwerendheid mee.

Een verdiepingsvloer kan bestaan uit in het werk gestort beton of uit **prefab vloerelementen**, zoals kanaalplaten of breedplaten. Een **staalplaatbetonvloer** bestaat uit geprofileerde staalplaten met daarop beton. De staalplaat dient bij het storten als blijvende bekisting. Als de vloer daarvoor is ontworpen, werkt het staal na verharding met het beton samen. Bij een uitkragend balkon kan een **thermisch onderbroken verbinding** krachten tussen balkon en verdiepingsvloer overdragen en tegelijk de koudebrug beperken.

Een **houten balklaag** draagt de vloerdelen of vloerplaten. Bij een samengestelde balklaag steunen kleinere **kinderbalken** op grotere **moerbalken**. Een **onderslagbalk** kan vloerbalken tussentijds ondersteunen en daarmee hun vrije overspanning verkleinen. Bij een trapgat vangt een **raveelbalk** de uiteinden van onderbroken vloerbalken op en leidt de belasting af naar doorgaande balken. Maak een opening daarom alleen met een passende constructieve voorziening.

## Geluid, brand en plafond

**Luchtgeluid**, zoals praten, bereikt de vloer via de lucht. De massa van beton helpt dit geluid tegen te houden. **Contactgeluid**, zoals voetstappen, brengt de constructie zelf in trilling. Een **zwevende dekvloer** op een veerkrachtige laag kan die overdracht verminderen als harde verbindingen met de draagvloer en wanden worden vermeden. Bij een houten vloer kan een ontkoppeld plafond met geluidabsorberend materiaal in de holle ruimte de geluidisolatie verbeteren. Een **verlaagd plafond** kan ook ruimte bieden voor leidingen. Waar brandwerendheid nodig is, telt de prestatie van de volledige vloer- en plafondopbouw, inclusief aansluitingen en doorvoeren.

## Trappen en veilig gebruik

De **optrede** is het verticale hoogteverschil tussen twee opeenvolgende treden. De **aantrede** is de horizontale afstand tussen de voorkanten van opeenvolgende treden, gemeten op de **looplijn**. Op een draaitrap zijn treden aan de binnenkant smaller. Op de looplijn moeten de aantreden gelijkmatig blijven, zodat het loopritme niet verandert. Bij het **verdrijven van treden** wordt de overgang van rechte naar draaiende treden geleidelijk over enkele treden verdeeld. De **vrije hoogte** is de ruimte boven de trap. Controleer ook de trapbreedte, stroefheid, verlichting en ruimte bij het begin en einde. Welke eisen gelden, hangt af van de situatie.

Een **steektrap** loopt recht. Een **kwartslagtrap** verandert een kwartslag van richting. Een **bordes** is een vlak platform tussen trapdelen. Bij een **spiltrap** liggen de treden rond een centrale spil. Een **trapboom** draagt de treden langs de zijkant. Een **stootbord** sluit de verticale opening tussen twee treden. Bij een **open trap** ontbreken stootborden. De **wel** is het deel van de trede dat aan de voorkant over de onderliggende opening of het stootbord uitsteekt. Een **leuning** geeft houvast. Een **vloerafscheiding** langs een open zijde beperkt het valrisico.

Een trap kan van hout, beton, staal of natuursteen zijn. Een **prefab betontrap** wordt vooraf gemaakt en op de bouwplaats gemonteerd. Een in het werk gestorte betontrap krijgt zijn vorm in een bekisting. Bij een stalen trap kunnen roostertreden worden toegepast. Bij elk systeem moeten de opleggingen, bevestigingen en afwerking passen bij de belasting en het gebruik.
