# Hoofdstuk 14 – Binnenkozijnen

## Kozijn en doorgang

Een **binnenkozijn** vormt de vaste omlijsting van een deur, raam of vast paneel. De verticale delen zijn de **stijlen**. De **bovendorpel** verbindt de stijlen bovenaan. Soms zit er onderaan een **onderdorpel**. Een **steldorpel** houdt de stijlen bij transport en plaatsing op afstand en is niet altijd zichtbaar in de afwerking. Een **bovenlicht** is een raam of glaspaneel boven de deur dat licht doorlaat. Een **sponning** is een uitsparing in het kozijn waar de deur, een paneel of glas in past of tegen sluit.

De **dagmaat** is de maat tussen de binnenkanten van de opening. De **vrije doorgang** is de ruimte die bij een geopende deur werkelijk beschikbaar is. Het deurblad of beslag kan daarbij in de weg zitten. De **deurmaat** is de afmeting van het deurblad zelf. Voor een eenvoudige breedteberekening bij een **stompe deur** tel je beide sponningdieptes op bij de dagmaat. Trek vervolgens de voorgeschreven speling links en rechts af. Controleer bij bestelling de maatvoering van het specifieke kozijn en deurtype. Op de plattegrond geeft een boog de **draairichting** van een draaideur aan. Controleer of het blad vrij kan draaien en de looproute vrij blijft.

## Plaatsing en aansluiting

Een **inmetselkozijn** wordt in de ruwbouw gesteld en in de muur opgenomen. Een **stelkozijn** vormt een voorbereid kader waarvoor later een passend **montagekozijn** wordt geplaatst. Sommige montagekozijnen komen tijdens de afbouw rechtstreeks in een uitgespaarde muuropening. Het kozijn moet recht en haaks staan, zodat de deur rondom voldoende speling heeft.

Een **kozijnanker** verbindt een houten kozijn met het metselwerk. Bij een **kalk- of speciesponning** wordt de uitsparing in de stijl met metselspecie gevuld. Dit beperkt een doorgaande naad wanneer het hout krimpt. De sponning vervangt het anker niet. Een **platstuk** of aftimmerlat dekt de zichtbare aansluiting tussen wand en kozijn af. Waar metselwerk boven een opening ondersteuning nodig heeft, draagt een **latei** de last af naar de muur naast de opening. Een gewoon binnenkozijn is daarvoor niet bedoeld. Een **neut** is een voetstuk onder een houten stijl, bijvoorbeeld van natuursteen. Het houdt het hout weg van vocht op de vloer.

## Kozijnmaterialen

Een **stalen binnenkozijn** kan uit gevormd plaatstaal bestaan. Stalen uitvoeringen zijn er voor inmetselen en voor montage achteraf. **Aluminium kozijnen** komen onder meer voor in systeemwanden. Bij een **kunststof montagekozijn** kunnen houten of metalen delen het profiel van binnen verstevigen. Kies een uitvoering die past bij de wand, de bevestiging en het deurblad.

## Deuren en verbindingen

Een **stompe deur** valt met de volle dikte in de sponning. Een **opdekdeur** heeft een opdekrand die een deel van het kozijn overlapt. Controleer of deur, kozijn en ophanging bij elkaar passen. Een **vlakke deur** kan bestaan uit randhout en vlakke platen met een lichte **honingraatvulling**. Bij een **paneeldeur** verdelen stijlen en dorpels het raamwerk in vakken met panelen. Een **opgeklampte deur** bestaat uit planken die door dwarsklampen bij elkaar worden gehouden. Een **schuifdeur** draait niet de kamer in. Ze schuift over een vloerrail of hangt aan een bovenrail, met ruimte langs of in de wand.

Een **brandwerende deur** werkt als onderdeel van een beproefde combinatie van deurblad, kozijn, beslag, afdichting en eventueel glas. De combinatie moet bij de vereiste prestatie passen en kunnen sluiten zoals ontworpen. Bij een **geluidwerende deur** beperken afdichtingen de geluidslekken langs de randen. Een **valdorpel** sluit de kier onder de deur bij het sluiten.

Bij een houten **pen-en-gatverbinding** grijpt een pen aan de stijl in een passend gat in de dorpel. Bij een **deuvelverbinding** verbinden ronde, verlijmde pennen de delen via voorgeboorde gaten.
