# Hoofdstuk 22 – Het platte dak

## Draagconstructie en afwatering

Een plat dak draagt zijn eigen gewicht en belastingen door onder meer wind, sneeuw en gebruik. De **draagconstructie** kan bestaan uit houten balken met dakbeschot, beton of geprofileerde staalplaten. De dakopbouw en bevestiging moeten bij de ondergrond en de belasting passen. **Afschot** is de lichte helling die regenwater naar de **hemelwaterafvoer** leidt. Het kan in de draagconstructie, een afwerklaag of in afschotisolatie zitten. Ook na doorbuiging moet het water kunnen wegstromen. Bij **wateraccumulatie** blijft water staan, waardoor het dak zwaarder wordt en verder kan doorbuigen. Een **noodafvoer** kan water afvoeren als de gewone afvoer het niet verwerkt. Bij een grindlaag houdt een **kiezelbak** grind weg uit de afvoer.

## Isolatie en vocht

Bij een **warm dak** ligt de isolatie boven de draagconstructie en onder de waterdichte dakbedekking. De draagconstructie blijft relatief warm. Een **dampremmende laag** aan de warme kant van de isolatie beperkt, waar nodig, het binnendringen van waterdamp in de dakopbouw. Bij een **koud dak** ligt de isolatie onder het dakbeschot. Het beschot blijft koud, waardoor bij een ongeschikte opbouw **condensatie** kan ontstaan. Luchtdichting en vochtbeheersing vragen hier extra aandacht. Bij een **omgekeerd dak** ligt de waterdichte laag onder vochtbestendige isolatie. Een geschikte **ballastlaag**, bijvoorbeeld grind of tegels, houdt de losse lagen op hun plaats tegen windzuiging. De **Rc-waarde** geeft de warmteweerstand van de dakconstructie aan. Hoe hoger die waarde, hoe minder warmte er bij hetzelfde temperatuurverschil door het dak stroomt.

Een **groendak** heeft begroeiing boven de waterdichte laag. Een **extensief groendak**, bijvoorbeeld met sedum, heeft een relatief dunne groeilaag. Een **intensief groendak** lijkt meer op een daktuin en vraagt meestal meer opbouwhoogte, draagvermogen en onderhoud. Beide vragen bescherming tegen wortels en een goed werkende afwatering. Het gewicht van natte lagen telt mee voor de constructie.

## Dakbedekking en aansluitingen

**Bitumineuze dakbedekking** wordt meestal geleverd in banen met een versterkende drager en bitumen aan beide zijden. **APP** en **SBS** zijn toevoegingen die de eigenschappen van het bitumen verbeteren. APP verhoogt onder meer de weerstand tegen hoge temperaturen. SBS maakt het materiaal elastischer. De banen worden afhankelijk van het systeem los met ballast gelegd, gekleefd of mechanisch bevestigd. Overlappen en naden moeten waterdicht worden verbonden.

**Kunststof- en rubberfolies** zijn alternatieven voor bitumineuze banen. **Pvc** is een thermoplastische folie waarvan geschikte naden met hete lucht kunnen worden gelast. **EPDM** is een elastische rubberfolie. De verbindingen worden gemaakt met de lijm, tape of andere naadtechniek van het systeem. Bij elke bedekking moeten de ondergrond, bevestiging en aansluitdetails bij elkaar passen.

Een **dakopstand** is de verhoogde rand langs een gevel, dakrand of opening. De dakbedekking wordt daar omhoog doorgezet om water buiten te houden. De overgang bij de voet van de opstand heet de **kim**. Een passend **dakrandprofiel** of afdekking beschermt de randafwerking. Een **lichtkoepel** of **lichtstraat** brengt daglicht binnen. De aansluiting op het dak moet waterdicht zijn. Houd de isolatie bij randen en openingen zo veel mogelijk doorlopend om koudebruggen en condensatie te beperken.
