# Bouwproces

# Start hier • jouw derde onderwerp

## Bouwproces in gewone taal
Dit pakket hoort bij Bouwkunde BT1, naast je eerdere onderwerpen. Je doorloopt korte lessen en oefent daarna. De vaktermen blijven staan en krijgen uitleg. Er is geen humor toegevoegd.

### Wat is gebruikt?
De 27 foto’s uit Fotos bouwproces.zip: pagina’s 3.1 tot en met 3.16 en 3.18 tot en met 3.28. Pagina 3.17 staat alleen gedeeltelijk op een naastliggende foto. Het ontbrekende deel is niet aangevuld. Hoofdstuk 4, dat op de laatste foto begint, hoort niet bij dit pakket.

Dit is een vereenvoudiging van de aangeleverde boekstof, geen actualisering van wetgeving. De samenvattingen geven de hoofdzaken en leggen begrippen uit. De foto's blijven je bron voor de volledige tekst. Alleen twee uitsneden voor oefeningen zijn in het pakket opgenomen.

### Bronpunten om bij je opleiding na te vragen

- De beschrijving van vergunningverlening en kwaliteitsborging op p. 3.7 is sterk verkort. Gebruik haar niet als volledig stappenplan voor een echte aanvraag.
- P. 3.9 noemt bij gietbouw een hoge isolatiewaarde. De pagina specificeert niet welke complete wandopbouw bedoeld wordt. Maak daarvan niet de regel dat beton op zichzelf goed isoleert.
- De tekst over houtbouw gebruikt op p. 3.13–3.14 algemene uitspraken over toepassing, onderhoud en hoogte. P. 3.22 bespreekt juist ontwikkelingen zoals CLT. Houd houtskeletbouw en andere houtbouwsystemen uit elkaar.
- P. 3.20 noemt MPG-grenswaarden en een datum in 2026. Ze zijn hieronder als bronvermelding opgenomen, niet zelfstandig gecontroleerd of als algemeen geldig toetsfeit gebruikt.
- De wetshistorie, de verwijzingen naar NMP 4 en BOOT’98 en de oude praktijkopdrachten zijn brongebonden. Lees oudere regels niet als een compleet overzicht van de huidige regels.
- P. 3.27 noemt bij asbest een verbodsdatum van 1 januari 1992 en formuleert algemeen dat aanwezig materiaal kan blijven zitten. Deze passage is geen betrouwbare beoordeling van de veiligheid van een concreet gebouw. De datum en die algemene geruststelling worden niet als toetsfeit gebruikt. Het pakket bevat geen instructies voor asbestverwijdering.

### Oefenen
De meerkeuze- en rekenvragen kijkt de app na. Open vragen controleer je met het voorbeeldantwoord. De afsluitende toets is gebaseerd op deze foto’s. Er is geen examen-PDF meegeleverd, dus dit is geen officiële of aantoonbaar examengelijke toets. Video’s zijn niet toegevoegd.

---

# 01 • Situering, oriëntatie en Kadaster

## Waar komt het gebouw?
**Situering** is de plaats van een gebouw op het terrein en in de omgeving. **Oriëntatie** gaat over hoe het gebouw ligt ten opzichte van de windrichtingen. Dat maakt verschil voor zonlicht. Ook moeten hulpdiensten het gebouw kunnen bereiken en moeten de stedenbouwkundige regels worden gevolgd.

Een **situatietekening** laat zien waar het gebouw en de perceelsgrenzen liggen. Je ziet bijvoorbeeld of een woning vrijstaat, welke tuinen er zijn en hoe het huis aan de straat ligt. De bron noemt: het te bebouwen perceel met kadastrale aanduiding, aangrenzende percelen, straatnaam, zo mogelijk huisnummers, voor-, achter- en zijgevelrooilijnen, noordpijl, schaal en schaalbalk. Een **rooilijn** geeft de lijn aan voor de plaatsing van een gevel.

### De zon en de schaal
Een woonkamer op het noorden krijgt volgens het beschreven voorbeeld vrijwel geen direct zonlicht. Bij **zongerichte verkaveling** worden percelen en gebouwen zo ingedeeld dat zonnewarmte gunstig kan worden benut. **Passieve zonne-energie** is hier de warmte van de zon die het gebouw binnenkomt.

De **noordpijl** geeft het noorden aan. Bij schaal **1 : 1000** stelt één eenheid op papier duizend van dezelfde eenheden in werkelijkheid voor. Dus 1 cm op papier is 1000 cm, oftewel 10 meter. Reken niet op een ingezoomde foto zonder rekening te houden met de oorspronkelijke schaal; de oefengetallen zijn fictief.

### Kadaster
Het **Kadaster** registreert de rechtstoestand van onroerende zaken: onder andere eigendom, erfdienstbaarheden, opstal, erfpacht en hypotheken. Het is een openbaar register dat volgens de bron tegen betaling geraadpleegd kan worden.

De gewone gemeente is de gemeente waarin het project ligt. De **kadastrale gemeente** verwijst naar de kadastrale indeling, die historisch teruggaat tot omstreeks 1830. Een **sectie** is een deel daarvan, aangeduid met een hoofdletter. Het **perceelnummer** duidt het perceel binnen die sectie aan. Verwissel een huisnummer dus niet met een perceelnummer.

**Bron:** LOI, Bouwproces, p. 3.1–3.3.

---

# 02 • Van eerste idee tot gebruik

## Bouwen begint vóór de bouwplaats
Het **bouwproces** omvat de stappen waarmee een idee een werkelijk gebouw wordt. De bron onderscheidt vier bouwfasen.

### 1. Initiatieffase
De opdrachtgever bepaalt wat hij wil. Hij stelt een plan of **programma van eisen** op: een overzicht van waaraan het gebouw moet voldoen. Er worden **haalbaarheidsstudies** gedaan: kan het plan werkelijk worden uitgevoerd, ook financieel?

### 2. Ontwerpfase
De ontwerper vertaalt die eisen naar een bouwkundig ontwerp. Het budget telt mee. De aanvraag voor de omgevingsvergunning wordt voorbereid.

### 3. Prijsvormingsfase
Er wordt een aannemer gezocht die het ontwerp voor een bedrag kan uitvoeren. De opdrachtgever kan één of meer **offertes** vragen: prijsaanbiedingen. Bij een **openbare aanbesteding** kunnen gekwalificeerde aannemers een aanbieding doen. **Gunning** is de bevestiging dat de aannemer de opdracht krijgt.

### 4. Uitvoeringsfase
De aannemer realiseert het gebouw volgens de afgesproken kaders en planning. Arbeid, materiaal en middelen moeten goed op elkaar aansluiten. De kosten moeten binnen het bouwbudget blijven.

Daarna volgen volgens deze indeling de **exploitatiefase of gebruiksfase** en uiteindelijk de **sloop**. Exploitatie is hier het gebruiken en in bedrijf houden van het gebouw. Het boek onderscheidt deze latere fasen van het bouwproces zelf.

Een eenvoudig leerhouvast is: eerst bepalen wat nodig is, dan ontwerpen, vervolgens prijs en aannemer bepalen, daarna uitvoeren. Dit is de hoofdvolgorde van de bron; samenwerkingsvormen kunnen partijen al eerder bij het ontwerp betrekken.

**Bron:** LOI, Bouwproces, p. 3.3–3.4.

---

# 03 • Primaire en secundaire planning

## De juiste mensen en spullen op het juiste moment
Een **primaire planning** is de algemene planning van het werk. Zij laat zien hoe en in welke volgorde de aannemer bouwt, welke middelen nodig zijn en hoeveel tijd ieder onderdeel mag duren. Het boek noemt een **balkenschema** als gebruikelijke vorm.

In een balkenschema stelt iedere balk een activiteit voor. De plaats laat zien wanneer deze begint en eindigt. De lengte geeft de duur aan. De werkzaamheden zijn geordend op hun eerste start. In het afgebeelde schema betekent zwart de planning en grijs de werkelijkheid.

Er wordt gerekend met **werkdagen**. Een **onwerkbare werkdag** is een dag, of een deel ervan, waarop door omstandigheden buiten de schuld van de aannemer niet gewerkt kan worden. Het bestek bepaalt wat daar in de betreffende afspraken onder valt. De planning en de werkelijke voortgang worden bijgehouden, bijvoorbeeld op een schema in de bouwkeet.

### De details: secundaire planning
De **secundaire planning** werkt de algemene planning verder uit:

- wanneer welke medewerkers nodig zijn;
- wanneer grondstoffen en bouwmaterialen moeten aankomen;
- wanneer kranen, kruiwagens en ander materieel nodig zijn;
- wanneer tekeningen van architect, onderaannemers en leveranciers beschikbaar moeten zijn.

**Afroepen** betekent dat je aan een leverancier doorgeeft wanneer eerder besteld materiaal op de bouwplaats geleverd moet worden. Het is dus niet hetzelfde als voor het eerst bestellen.

**Materiaal** wordt in het gebouw verwerkt, zoals stenen. **Materieel** zijn hulpmiddelen om te bouwen, zoals een kraan.

De bron beschrijft ook een **veiligheids- en gezondheidsplan (V&G-plan)** voor de uitvoering, gebaseerd op het V&G-plan uit het ontwerp. Planning gaat dus niet alleen om snel bouwen, maar ook om een veilige organisatie.

**Bron:** LOI, Bouwproces, p. 3.4–3.6.

---

# 04 • Wie doet wat op een bouwproject?

## Verschillende rollen
De **opdrachtgever**, ook **principaal**, neemt het initiatief, geeft wensen en eisen aan en zorgt voor financiering. Dit kan een particulier zijn, maar ook een corporatie, ontwikkelaar, bedrijf of overheid. Hij neemt belangrijke beslissingen over ontwerp, kosten en planning en kan zich laten adviseren.

De **architect** maakt het ontwerp en de tekeningen en overlegt met opdrachtgever en andere betrokkenen. De **constructeur** rekent aan de draagconstructie. Een **installatieadviseur** houdt zich bezig met de installaties. Een bouwmanagementbureau kan de organisatie ondersteunen.

De **aannemer** organiseert en realiseert het werk op de bouwplaats. Hij stuurt de uitvoering aan en schakelt onderaannemers en leveranciers in. De aannemer blijft volgens de bron verantwoordelijk voor het werk van zijn onderaannemers.

De **uitvoerder** vertegenwoordigt de aannemer op het werk. Hij regelt dagelijks planning, afstemming, veiligheid en kwaliteit. Een **onderaannemer** voert een gespecialiseerd deel uit, bijvoorbeeld heiwerk of installaties.

### Overheid en kwaliteitscontrole
De gemeente heeft taken rond de beoordeling van een bouwplan, vergunningverlening en toezicht op regels. Het boek noemt omgevingsplan en Bbl. De **onafhankelijke kwaliteitsborger** heeft bij de beschreven kwaliteitsborging een rol in de controle op technische eisen. Dit is een verkorte uitleg; de tekst is geen compleet overzicht van alle procedures en toepassingsvoorwaarden. Brandweer en milieudienst kunnen advies geven.

### De makelaar
Een **projectontwikkelaar** kan planontwikkeling, financiering en verkoop combineren. Een **makelaar** kan helpen bij koop en verkoop en adviseren over marktbehoefte, prijs en indeling. Hij brengt dus kennis in over wat toekomstige bewoners zoeken.

**Bron:** LOI, Bouwproces, p. 3.7.

---

# 05 • Bouwteam, turnkey, PPS en ontwikkeling

## Wie werkt wanneer samen?
Een **bouwteam** is samenwerking voor één project tussen opdrachtgever, ontwerpers en adviseurs, vaak met de aannemer erbij. Zij denken al in de ontwerpfase samen na over kosten, techniek, planning, budget en uitvoerbaarheid. Daardoor kan het ontwerp beter passen bij hoe het werkelijk wordt gebouwd. De tekst noemt een kortere doorlooptijd, betere risicobeheersing en duidelijkere rollen als mogelijke voordelen.

### Turnkey
Bij een **turnkeyovereenkomst** geeft de opdrachtgever het hele project aan één partij die ontwerp én uitvoering verzorgt. Het resultaat wordt **sleutelklaar** opgeleverd. De opdrachtgever levert een programma van eisen aan.

Voordeel: één aanspreekpunt en minder coördinatiewerk. Nadeel: de opdrachtgever heeft minder rechtstreekse invloed op ontwerpkeuzes en veranderingen, omdat de opdrachtnemer het totale proces beheert.

### PPS
**PPS** betekent publiek-private samenwerking. De overheid en marktpartijen realiseren samen een project en delen risico’s en verantwoordelijkheden. Dit komt volgens de tekst vooral voor bij grote infrastructuur- en overheidsprojecten, zoals wegen, tunnels en overheidsgebouwen.

Vaak betaalt de overheid voor gebruik of beschikbaarheid. Private partijen organiseren bijvoorbeeld ontwerp, bouw en onderhoud en soms financiering. Voordelen zijn gebundelde kennis en een betere verdeling van risico’s. Nadelen zijn ingewikkelde contracten en minder directe overheidssturing.

### Projectontwikkeling
Een projectontwikkelaar kan grond verwerven, plannen ontwikkelen, financiering organiseren en verkopen. Hij stuurt ontwerpers, adviseurs en aannemer aan en bewaakt de technische, financiële en commerciële haalbaarheid. Verkoop of verhuur wordt vaak samen met makelaars georganiseerd.

Let op: dit zijn samenwerkings- en organisatievormen. Ze zeggen op zichzelf nog niet of de muren worden gemetseld, gegoten of als prefab geplaatst.

**Bron:** LOI, Bouwproces, p. 3.8.

---

# 06 • Traditionele bouw en gietbouw

## Hoe wordt het gebouw gemaakt?
Een **bouwmethode** is de manier waarop een gebouw op de bouwplaats wordt gemaakt. De keuze hangt af van omvang, ontwerp, duurzaamheidsambities, budget en beschikbare ruimte.

Bij **traditionele bouw of stapelbouw** worden onderdelen vooral op de bouwplaats gestapeld, gemetseld of verbonden. De bron noemt een lange levensduur, stabiliteit, ontwerpvrijheid, beperkte temperatuurschommelingen en goede akoestische prestaties als voordelen. Nadelen zijn veel handelingen op de bouwplaats en een relatief zware constructie. Daardoor kan ook een zwaardere fundering nodig zijn.

**Moderne stapelbouw** combineert werkwijzen. Vloeren en vaak het dak kunnen als prefab worden aangevoerd, terwijl muren op de bouwplaats worden gemetseld of gelijmd. Een gebouw kan dus meerdere bouwmethoden combineren.

### Gietbouw
Bij **gietbouw** worden betonnen wanden en vloeren ter plaatse in een **bekisting** gestort. Een bekisting is de mal die het verse beton zijn vorm geeft.

- Voor wanden kunnen stalen bekistingspanelen worden gebruikt.
- Een **tafelbekisting** is een grote plaat op een onderbouw om vloeren te storten. Een kraan brengt haar op de plaats.
- Met een **tunnelbekisting** worden wanden en vloeren samen in één keer gestort.

Stalen bekisting is duur. Je gebruikt haar daarom vaak opnieuw: **repetitie**. Een kraan moet efficiënt worden ingezet; de capaciteit van die kraan beïnvloedt het bouwtempo.

De overzichtslijst noemt een snelle bouwtijd en minder ontwerpflexibiliteit bij gietbouw. Zij noemt ook een hoge isolatiewaarde zonder de wandopbouw uit te werken. Zie de bronnotitie bij Start hier: leid daar niet uit af dat beton op zichzelf goed isoleert.

**Bron:** LOI, Bouwproces, p. 3.8–3.10.

---

# 07 • Prefab en montagebouw

## Eerst maken, daarna monteren
**Prefab** betekent vooraf vervaardigd. Bij **elementenbouw** worden bouwdelen in de fabriek gemaakt en op de bouwplaats samengevoegd. Bij de beschreven **montagebouw** worden dragende wanden en vloeren uit zulke elementen met kranen gemonteerd.

De elementen kunnen al ingestorte leidingen hebben. Openingen voor deuren en ramen zijn al gemaakt. Betonnen wandelementen kunnen verdiepingshoog en zo lang als een vertrek zijn.

De overzichtslijst noemt een korte bouwtijd, goede kwaliteit en minder afhankelijkheid van het weer. Daartegenover staat minder vrijheid om het ontwerp later aan te passen. De werkzaamheden en aansluitingen moeten vooraf goed worden bedacht.

### Twee manieren om elementen te verbinden
Bij de **natte methode** worden elementen eerst gesteld: nauwkeurig op hun plek en hoogte gezet. Stelblokjes helpen daarbij. Ruimten tussen elementen worden vervolgens met beton of mortel gevuld.

Bij de **droge methode** worden gestelde elementen met bijvoorbeeld bouten en strippen verbonden. Kieren worden volgens de tekst met kit of purschuim gedicht. Nat en droog gaan hier over de verbinding, niet over het weer tijdens de bouw.

### Waarom kwam prefab op?
Na de Eerste Wereldoorlog was er een woningachterstand. Rond 1920 experimenteerden Amsterdam, Rotterdam en Den Haag met industriële woningbouw. Het boek noemt Betondorp in de Watergraafsmeer. In de jaren dertig verminderde de belangstelling toen traditionele bouw goedkoper werd. Na de Tweede Wereldoorlog groeide de belangstelling weer door oorlogsschade en woningnood. De bron koppelt de situatie in 2025 aan woningvraag en personeelsschaarste. Dat is een tijdsaanduiding uit de bron.

**Bron:** LOI, Bouwproces, p. 3.10–3.12.

---

# 08 • Staalskelet, hallen en houtskelet

## Een skelet draagt het gebouw
Bij **staalskeletbouw** worden kolommen en balken in de fabriek op maat gemaakt en op de bouwplaats gemonteerd. De verbindingen zijn bijvoorbeeld gebout of gelast. Dit is ook montagebouw.

Staal maakt een relatief lichte, stijve constructie met grote **overspanningen** mogelijk: grote afstanden tussen steunpunten. Dat is bruikbaar voor fabrieken en loodsen. De tekst noemt ook ruimte voor veel glas en de mogelijkheid tot uitbreiden en veranderen. Akoestiek is een aandachtspunt.

Een **windverband** bestaat hier uit diagonale staven. Ze vormen met kolommen en liggers stijve driehoeken. Dat voorkomt **schranken**: het scheeftrekken van het raamwerk.

Staal verliest bij sterke verhitting sterkte. De tekst bespreekt daarom brandwerende bekleding. **Hallenbouw** combineert grote hoogte met grote overspanningen, bijvoorbeeld voor een vliegtuighangar of scheepsbouwhal.

### Houtskeletbouw, afgekort HSB
Een houten raamwerk vormt de basis. De verticale onderdelen heten **stijlen** en de horizontale **regels**. Plaatmateriaal zorgt mede voor stijfheid. HSB is een vorm van montagebouw.

De bron noemt als voordelen: laag gewicht, snelle en eenvoudige montage, een droge bouwmethode, goede isolatiemogelijkheden, variatie, zelfwerkzaamheid en mogelijkheden voor recycling. Een lichte constructie heeft gevolgen voor de benodigde fundering. Als aandachtspunten noemt de tekst onderhoud in een vochtig klimaat, akoestiek en beperkingen voor hoge gebouwen. Dit zijn algemene bronuitspraken over HSB, niet over elk modern houtbouwsysteem.

Niet alles hoeft hout te zijn. Een geïsoleerde steenachtige beganegrondvloer en een bakstenen gevelbekleding zijn ook mogelijk. De historische voorbeelden zijn de Zaanstreek, Canada en Scandinavië. Bomen slaan tijdens hun groei CO₂ op; dat verklaart mede de aandacht voor houtbouw.

**Bron:** LOI, Bouwproces, p. 3.9 en 3.12–3.14.

---

# 09 • Passiefhuis, NOM en compact bouwen

## Duurzaam bouwen gaat over mens én milieu
**Duurzaam bouwen** is het ontwikkelen en beheren van de gebouwde omgeving met respect voor mens en milieu. Energiezuinigheid is daar een onderdeel van, maar materiaalkeuze en hergebruik tellen ook mee.

**BENG** staat voor Bijna Energieneutraal Gebouw. De bron noemt eisen voor energiebehoefte, fossiel energiegebruik en hernieuwbare energie. De precieze grenswaarden worden hier niet uitgewerkt.

### Passiefhuis
Een **passiefhuis** heeft een zeer goede **thermische schil**: de buitenmuren, vloer, dak en beglazing die binnen van buiten scheiden. Sterke isolatie, drievoudig glas en weinig ongewenste luchtlekken beperken warmteverlies.

Een belangrijk deel van de warmte komt van zoninstraling, bewoners en apparatuur. Dat zijn **passieve warmtebronnen**. Vaak is er balansventilatie met **warmteterugwinning (WTW)**. Warmte uit de afgevoerde lucht helpt de binnenkomende buitenlucht op te warmen. Warmte terugwinnen is niet hetzelfde als verse lucht weglaten.

### Nul-op-de-meter en energieneutraal
Een **NOM-woning** wekt volgens de tekst op jaarbasis ongeveer evenveel duurzame energie op als nodig is voor gebouwgebonden installaties en vaak ook huishoudelijk gebruik. Isolatie, luchtdichtheid, efficiënte installaties en zonnepanelen werken samen. NOM kan bij nieuwbouw en ingrijpende renovatie.

**Energieneutraal** wordt in de praktijk breder en minder strikt gebruikt. Het gaat ook om een jaarlijkse energiebalans, maar de exacte voorwaarden kunnen per regeling of opdrachtgever verschillen. Gebruik die termen dus niet gedachteloos als volledig uitwisselbaar.

### Compact bouwen
Een compacte woning heeft relatief weinig buitenoppervlak in verhouding tot haar vloeroppervlak. Er kan dan minder warmte via de schil verloren gaan en er is minder materiaal voor die schil nodig. Een rijwoning of appartement heeft bijvoorbeeld minder vrijliggende gevels dan een vrijstaande woning.

De tekst vervolgt met duurzame installaties. De volledige p. 3.17 ontbreekt in de foto's; de ontbrekende uitleg is niet aangevuld. Het zichtbare vervolg benadrukt dat schil, installaties en bewonersgedrag samen het energiegebruik bepalen en dat WTW vooral goed werkt bij kierdichte woningen.

**Bron:** LOI, Bouwproces, p. 3.15–3.16 en 3.18 (vervolg).

---

# 10 • Duurzame materialen en materialenpaspoort

## Een materiaal is niet duurzaam door alleen zijn naam
Bij **duurzame bouwmaterialen** beoordeel je de hele levensloop: winning, productie, gebruik en einde van de levensduur. Belangrijk zijn een lage milieubelasting, weinig schadelijke uitstoot, een lange levensduur, onderhoudbaarheid, weinig verbruik van nieuwe grondstoffen en mogelijkheden voor hergebruik of recycling.

**Biobased materialen** komen uit biologische grondstoffen. Voorbeelden uit de tekst zijn hout, kruislaaghout (**CLT**) en plantaardige isolatie. **Secundaire materialen** komen uit eerder gebruik, bijvoorbeeld betongranulaat, hergebruikt staal of opnieuw gebruikte baksteen en natuursteen.

Materialen met weinig uitstoot van **vluchtige organische stoffen (VOS)** en formaldehyde kunnen bijdragen aan een gezond binnenklimaat. De keurmerken **FSC** en **PEFC** worden in het boek genoemd voor duurzaam bosbeheer. Ze betekenen niet automatisch dat hout gerecycled is.

### Materialenpaspoort
Een **materialenpaspoort** is een digitale registratie van wat in een gebouw zit. Per onderdeel legt het bijvoorbeeld vast welk materiaal is gebruikt, hoeveel, waar het vandaan komt, hoe het hergebruikt kan worden en wat de verwachte restwaarde is.

**Madaster** is in deze uitleg een platform voor zulke materiaalgegevens. Het gebouw wordt benaderd als een voorraad bruikbare materialen. Goede gegevens helpen later onderdelen gericht terug te winnen.

### Losmaakbaar ontwerpen
Als onderdelen later zonder onnodige schade uit elkaar kunnen, zijn ze makkelijker opnieuw te gebruiken. Denk aan demontabele verbindingen, schroeven in plaats van vastlijmen waar dat passend is, en materialen die goed gescheiden kunnen worden. De ontwerper en werkvoorbereider moeten de materiaalgegevens duidelijk en volledig vastleggen.

Een paspoort alleen maakt iets nog niet herbruikbaar. Ook de gekozen verbindingen, de toestand van het materiaal en de manier waarop het verwerkt is tellen mee.

**Bron:** LOI, Bouwproces, p. 3.18–3.20.

---

# 11 • LCA, MPG en duurzaamheidscertificaten

## Vergelijk meer dan de aanschafprijs
Een **levenscyclusanalyse (LCA)** brengt milieubelasting over de hele levensduur in beeld. Je kijkt naar grondstoffenwinning, productie, transport, gebruik, onderhoud en wat er na gebruik gebeurt: hergebruik, recycling of afvalverwerking. Als je varianten op dezelfde manier doorrekent, kun je hun milieueffecten vergelijken.

De **MilieuPrestatie Gebouwen (MPG)** vat in de beschreven toepassing de milieubelasting van de toegepaste bouwmaterialen samen in één getal. De bron drukt dit uit per vierkante meter gebruiksoppervlak per jaar. **Een lagere MPG betekent een lagere berekende milieubelasting.** LCA-gegevens van materialen en producten vormen de basis voor de berekening.

De bron noemt voor woningen maximaal 1,6 en voor kantoren maximaal 1,55 per 1 juli 2026. Dit zijn de waarden zoals ze op p. 3.20 staan. Ze zijn in dit pakket niet als actuele algemene norm gecontroleerd; gebruik ze niet zonder toepassingscontext voor een werkelijk plan. De toets richt zich op de betekenis van LCA en MPG.

### BREEAM en LEED
Een **duurzaamheidscertificaat** beoordeelt volgens deze tekst vrijwillig hoe duurzaam een gebouw is, bovenop wettelijke minimumeisen. Een opdrachtgever, belegger of gebruiker kan zo’n beoordeling wensen.

**BREEAM** beoordeelt meerdere thema’s, zoals energie, water, materialen, afval, gezondheid, binnenklimaat, locatie en beheer. Punten leiden tot een beoordelingsniveau. De tekst noemt bijvoorbeeld Good, Very Good, Excellent en Outstanding.

**LEED** is een internationaal, oorspronkelijk Amerikaans certificeringssysteem met vergelijkbare thema’s. Het komt volgens de tekst vaak voor bij projecten met internationale opdrachtgevers of gebruikers.

Houd drie dingen uit elkaar: LCA is een analysemethode, MPG is een materiaalgerelateerde gebouwindicator en BREEAM/LEED zijn bredere beoordelingssystemen. Certificeringswensen kunnen al bij ontwerp, materiaalkeuze, uitvoering en onderhoud extra eisen geven.

**Bron:** LOI, Bouwproces, p. 3.20–3.21.

---

# 12 • Industrialisatie, circulariteit en slimme gebouwen

## Veranderingen in de bouw
Het boek koppelt ontwikkelingen aan klimaatdoelen, schaarse grondstoffen, personeel, industrialisatie en digitalisering. Kennisinstellingen zoals TNO, onderzoeksprogramma’s en brancheorganisaties ontwikkelen en onderzoeken nieuwe mogelijkheden.

**Industrialisatie** betekent hier dat meer gecontroleerd in de fabriek wordt geproduceerd. Voorbeelden zijn prefabbeton, houtskeletelementen en grote houten panelen zoals CLT. Mogelijke voordelen zijn een kortere bouwtijd op de bouwplaats, minder faalkosten, minder weersinvloed, beter controleerbare kwaliteit en minder afval. De tekst noemt ook 3D-printen van woningelementen.

### Circulair en cradle to cradle
Bij een **circulaire economie** blijven materialen en grondstoffen zo lang mogelijk bruikbaar. Hergebruik, losmaakbaar ontwerpen en het scheiden van materiaalstromen horen daarbij.

**Cradle to cradle** betekent letterlijk van wieg tot wieg. Het streven is dat een materiaal na gebruik weer een waardevolle grondstof wordt. **Cradle to grave**, van wieg tot graf, eindigt met afval. De tekst noemt bijvoorbeeld producten die opnieuw grondstof worden, geschikte producten die compost kunnen worden en productie zonder schadelijk afval. Het gaat om een ontwerpdoel, niet om de garantie dat elk product dit al kan.

LCA en MPG helpen de milieugevolgen in cijfers uit te drukken. Een materialenpaspoort helpt vastleggen wat er werkelijk aanwezig is. Zo hangen de begrippen samen.

### Slimme installaties
**Domotica** en **smart building-technieken** helpen installaties regelen, energiegebruik volgen en comfort en veiligheid verbeteren. Een gebouw kan bijvoorbeeld reageren op gebruik, weer en energietarieven. De tekst noemt daarnaast warmtepompen, zonne-energie en warmteterugwinning als onderdelen van energiezuinige concepten.

Voor een bouwkundige of makelaar betekent dit dat vakkennis moet worden bijgehouden. Een ontwikkeling in de tekst is geen bewijs dat ieder bestaand gebouw die techniek al heeft.

**Bron:** LOI, Bouwproces, p. 3.22–3.23 en 3.26–3.27.

---

# 13 • Milieu, afvalhiërarchie en scheiden

## Afval hoort bij de planning
Bouwen, verbouwen en slopen leveren afval op. Het boek bespreekt dit aan de hand van NMP 4, de Wet milieubeheer en uitvoeringsregels. Het geeft ook een wetshistorie: eerdere sectorale wetten, de Wet milieubeheer uit 1993, de Wabo vanaf 1 oktober 2010 en de Omgevingswet vanaf 1 januari 2024. De precieze verdeling van huidige regels is daarmee niet volledig beschreven.

De **Wet milieubeheer (Wm)** wordt uitgelegd als kader voor milieubescherming, onder andere stoffen, handhaving, openbaarheid van milieu-informatie en beroepsmogelijkheden. De tekst benadrukt hoofdstuk 10 over afvalstoffen: onder andere huishoudelijk afval, afvalwater, bedrijfsafval, gevaarlijk afval en grensoverschrijdend afvalvervoer.

### De afvalhiërarchie: wat heeft de voorkeur?

- 1. **Preventie:** voorkom dat afval ontstaat.
- 2. **Voorbereiding voor hergebruik:** maak een gebruikt product geschikt om opnieuw te gebruiken.
- 3. **Recycling:** verwerk afval tot opnieuw bruikbaar materiaal.
- 4. **Andere nuttige toepassing:** bijvoorbeeld energieterugwinning.
- 5. **Veilige verwijdering:** de laatste stap in deze volgorde.

### Verschillende afvalstromen
De bron noemt aparte fracties voor puin, hout, metaal, glas, papier/karton, chemisch afval, kunststoffen en restmateriaal. Voorbeelden: beton en dakpannen bij puin; pallets bij hout; koper en staal bij metaal; kit- en verfresten bij chemisch afval. De lijst is een leerindeling uit de tekst, geen complete acceptatielijst van een afvalverwerker.

Gescheiden inzamelen helpt hergebruik en verwerking. De tekst noemt lagere stortkosten voor gescheiden afval en vrijwillige afspraken (**convenanten**) waarbij fabrikanten materiaalresten terugnemen, bijvoorbeeld steenwol.

**Bodem-, water- en luchtvervuiling** zijn de drie genoemde vormen van vervuiling. De bouw, andere industrie, landbouw, vervoer en huishoudens kunnen daaraan bijdragen. Ook natuurlijk materiaal moet op de juiste manier verwerkt worden.

**Bron:** LOI, Bouwproces, p. 3.23–3.25.

---

# 14 • Milieugevolgen van bouwmethoden

## Kijk naar het werkproces
De manier van bouwen beïnvloedt het milieu. Prefabproductie kan voordelen hebben doordat in een fabriek productie en afvalverwerking beter te controleren zijn.

De bron noemt bij prefab:

- minder resten en betere mogelijkheden om die opnieuw te gebruiken;
- afval beter gescheiden houden;
- afvoerlucht van werkplaatsen filteren;
- zuiniger met energie en grondstoffen omgaan;
- mogelijkheden voor fabrieksmatige oppervlaktebehandeling, zoals poedercoaten.

Bij traditionele bouw noemt de tekst meer restverliezen van baksteen, hout en dakpannen, veel verpakkingen en materiaalbederf door regen of sneeuw. Ook noemt zij uitstoot uit spuitbussen. Dat laatste staat in een historische beschrijving met cfk’s; maak daarvan geen uitspraak over iedere huidige spuitbus.

### Niet alle prefab is hetzelfde
De tekst maakt binnen de methoden onderscheid:

- **Houtskeletbouw:** kan veel ontwerpvrijheid bieden; materiaalresten kunnen bruikbaar zijn en de materiaalkeuze kan gunstig zijn.
- **Montagebouw:** doorgaans weinig restverliezen doordat elementen vooraf gemaakt zijn; purschuim en afdichtingskit zijn aandachtspunten.
- **Gietbouw:** de bron benadrukt energie- en watergebruik, restafval en beperktere ontwerpkeuze.

Dit zijn algemene vergelijkingen in het boek. De werkelijke milieuprestatie hangt ook af van het gekozen materiaal, energiegebruik, levensduur, onderhoud en mogelijkheden na gebruik. Daarom bespreekt dezelfde tekst de LCA. Alleen het etiket prefab of hout is niet genoeg voor een volledige vergelijking.

Een eenvoudige denkvraag is: hoeveel gaat verloren, hoe netjes kan afval gescheiden worden, hoeveel energie en water zijn nodig, en wat kan later opnieuw worden gebruikt?

**Bron:** LOI, Bouwproces, p. 3.25–3.26.

---

# 15 • Bestaande gebouwen, tanks en bodem

## Milieugevolgen stoppen niet na de bouw
Ook tijdens gebruik en onderhoud kunnen materialen milieueffecten hebben. De bron noemt bijvoorbeeld emissies uit plaatmateriaal en lijmen, radongas uit bepaalde minerale materialen, bitumineuze dakbedekking, bepaalde kunststoffen en isolatiematerialen. Dat zijn aandachtspunten, geen uitspraak dat ieder product in die groep in iedere situatie hetzelfde risico oplevert.

### Asbest in de bron
De tekst noemt oude toepassingen in golfplaten en leien, bepaalde plaatbekledingen, vloerbedekking, branddeuren, platen bij kachels en leidingen. Het kernpunt voor deze les is: een bestaand gebouw kan materiaal bevatten dat bij bewerken of verwijderen bijzondere risico’s geeft. De tekst noemt daarvoor gespecialiseerde bedrijven.

De bron bevat ook een specifieke verbodsdatum en een algemene geruststelling over aanwezig asbest. Die staan bij Start hier als controlepunt. Ze worden niet overgenomen als veiligheidsadvies of als goed/fout-toetsfeit. Dit is geen handleiding om materiaal zelf te beoordelen of te verwijderen.

### Ondergrondse olietanks
Het boek bespreekt oude huisbrandolietanks die buiten gebruik zijn geraakt. Lekkage kan bodemverontreiniging veroorzaken. Het noemt BOOT’98, een verwijderingsregeling vanaf 1999 en gespecialiseerde KIWA-erkende bedrijven. Ook noemt het bij nog gebruikte tanks keuring en verzekering. Dit zijn de regels zoals in deze historische passage beschreven, geen bijgewerkt praktijkprotocol.

Voor de makelaar is de praktische bronvraag: is er een tank geweest, is die gesaneerd, hoe is dat gebeurd en door wie? Vraag ook naar het **KIWA-certificaat**. Alleen horen dat de tank weg is, vertelt niet hoe het is uitgevoerd. De bron noemt mogelijke gevolgen van het opzettelijk verzwijgen van een gebrek, zonder alle voorwaarden van aansprakelijkheid uit te werken.

### Besluit bodemkwaliteit
Het **Bbk** stelt in de beschreven context regels aan bouwstoffen die in contact kunnen komen met regen-, grond- of oppervlaktewater. Het wil vervuiling door **uitlogen** voorkomen én hergebruik bevorderen. Uitlogen betekent dat stoffen uit materiaal vrijkomen in water en zo de omgeving kunnen bereiken. Het kan ook spelen bij een tuin ophogen, een buitenmuur of dakwerk.

Tot slot noemt de bron milieucriteria voor draagbare en verrijdbare brandblussers: onder andere de afbreekbaarheid van het blusmiddel en het vermijden van cfk’s of verwante stoffen. Dit is geen volledige productselectie- of gebruiksinstructie.

**Bron:** LOI, Bouwproces, p. 3.27–3.28.

---

# 16 • Pas de bouwproceskennis toe

## Van losse begrippen naar een project
De bron sluit af met eigen activiteiten. Je onderzoekt daarbij informatie van de gemeente over plannen, een mogelijke vergunningaanvraag en milieuvriendelijk bouwen. De bron noemt ook oudere termen en verwijzingen. Gebruik die opdrachten om te begrijpen welke informatie je nodig hebt; dit pakket vult geen echte aanvraag in en voert geen vergunningcheck uit.

### Oefencasus: een kleine woning bouwen
Dit is een verzonnen oefensituatie om de boekbegrippen toe te passen, geen extra examenstof. Een opdrachtgever wil een kleine woning. Het budget is beperkt. De bouwplaats is krap en de opdrachtgever wil weinig afval.

Begin met het programma van eisen. Onderzoek de situering: wat zijn de perceelsgrenzen, hoe staat het huis ten opzichte van de zon en hoe is het bereikbaar? Vertaal de eisen naar een ontwerp. Vergelijk bouwmethoden op kosten, ruimte op de bouwplaats, uitvoering en materiaalgebruik. Vraag in de prijsvormingsfase passende aanbiedingen.

Daarna moeten de primaire en secundaire planning op elkaar aansluiten. Het heeft geen zin een kraan te reserveren als de elementen niet geleverd worden, of medewerkers te laten komen zonder beschikbare tekeningen.

Kijk bij duurzaamheid naar zowel energie als materialen. Denk aan de schil, installaties en compactheid, maar ook aan LCA, hergebruik, verbindingen en materiaalregistratie. Regel afvalstromen vooraf.

### Drie opdrachten uit de bron in gewone taal

- Zoek voor een woning uit welke gemeentelijke planinformatie beschikbaar is. Schrijf op welk plan en welke locatie je hebt bekeken.
- Oefen met de informatie die nodig is voor een mogelijke dakkapel of serre. Doe dit als leeropdracht; dien niet per ongeluk een echte aanvraag in.
- Zoek welke informatie gemeente of Rijk geeft over milieuvriendelijk bouwen, bijvoorbeeld voor een garage. Noteer welke informatie over energie gaat en welke over materialen of afval.

Deze externe onderzoeksopdrachten zijn optioneel en vragen internet of contact met de gemeente. Alle samenvattingen en interactieve vragen in dit pakket werken offline.

**Bron:** LOI, Bouwproces, p. 3.28; toepassing van p. 3.1–3.27.